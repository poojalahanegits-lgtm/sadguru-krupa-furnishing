import React, { useState, useEffect, useMemo } from "react";
import { FiArrowLeft, FiSearch, FiX } from "react-icons/fi";
import AddOrder from "./AddOrder";
import ProductForm from "./ProductForm";
import ConfirmModal from "./common/ConfirmModal";
import { toast } from "react-toastify";

const OrderDetailsPage = ({
  customer,
  orders,
  onBack,
  onDeleteOrder,
  onDeleteProduct,
  onAddNewOrder,
  customers,
  onUpdateCustomer,
  onUpdateOrder,
  onUpdateProduct,
}) => {
  const [showAddOrderForm, setShowAddOrderForm] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(customer);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [editingOrder, setEditingOrder] = useState(null);
  const [editingProductState, setEditingProductState] = useState(null); // Track product being edited
  const [editingProductOrderId, setEditingProductOrderId] = useState(null); // Track which order contains the product
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState(null);
  const [productToDelete, setProductToDelete] = useState(null);
  const [productOrderId, setProductOrderId] = useState(null);
  const [showProductDeleteModal, setShowProductDeleteModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const closeAllPanels = () => {
    setEditingCustomer(null);
    setEditingOrder(null);
    setEditingProductState(null);
    setEditingProductOrderId(null);
    setShowAddOrderForm(false);
  };
  const handleOrderCreated = (newOrder) => {
    setShowAddOrderForm(false);

    const completeOrder = {
      ...newOrder,
      id: "o" + Date.now(),
      orderNo: newOrder.orderNo || `ORD-${Date.now()}`,
      createdAt: new Date().toISOString(),
      customerId: selectedCustomer.id,
    };

    if (onAddNewOrder) {
      onAddNewOrder(completeOrder);
    }
  };

  const deleteOrder = (orderId) => {
    setOrderToDelete(orderId);
    setShowDeleteModal(true);
  };
  const confirmDeleteOrder = () => {
    if (onDeleteOrder && orderToDelete) {
      onDeleteOrder(orderToDelete);
    }
    setShowDeleteModal(false);
    setOrderToDelete(null);
    setEditingOrder(null);
  };
  const deleteProduct = (orderId, productId) => {
    setProductOrderId(orderId);
    setProductToDelete(productId);
    setShowProductDeleteModal(true);
  };
  const confirmDeleteProduct = () => {
    if (onDeleteProduct && productOrderId && productToDelete) {
      onDeleteProduct(productOrderId, productToDelete);
    }

    // Reset states
    setShowProductDeleteModal(false);
    setProductToDelete(null);
    setProductOrderId(null);

    // If editing same product → reset
    if (editingProductState?.id === productToDelete) {
      setEditingProductState(null);
      setEditingProductOrderId(null);
    }
  };
  const handleUpdateCustomer = () => {
    if (onUpdateCustomer && editingCustomer) {
      onUpdateCustomer(editingCustomer);
      setSelectedCustomer(editingCustomer);
    }
    toast.success("Customer details updated successfully!");
    setEditingCustomer(null);
    setShowAddOrderForm(false);
  };

  const handleUpdateOrder = (updatedOrder) => {
    if (onUpdateOrder) {
      const originalOrder = orders.find((o) => o.id === updatedOrder.id);

      const finalOrder = {
        ...updatedOrder,
        products: [
          ...(originalOrder?.products || []), // old products
          ...(updatedOrder.products || []), // new products
        ],
      };

      onUpdateOrder(finalOrder);
    }

    setEditingOrder(null);
  };

  const startProductEdit = (orderId, product) => {
    closeAllPanels(); // ✅ important
    setEditingProductState(product);
    setEditingProductOrderId(orderId);
  };
  // const startProductEdit = (orderId, product) => {
  //   setEditingProductState(product);
  //   setEditingProductOrderId(orderId);
  //   // Clear other editing states
  //   setEditingOrder(null);
  //   setEditingCustomer(null);
  //   setShowAddOrderForm(false);
  // };

  const handleUpdateProductInline = (field, value) => {
    setEditingProductState((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const saveProductEdit = () => {
    if (onUpdateProduct && editingProductOrderId && editingProductState) {
      onUpdateProduct(editingProductOrderId, editingProductState);
      setEditingProductState(null);
      setEditingProductOrderId(null);
    }
    toast.success("Product details updated successfully!");
  };

  const cancelProductEdit = () => {
    setEditingProductState(null);
    setEditingProductOrderId(null);
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm);
    }, 300); // 300ms delay

    return () => clearTimeout(timer);
  }, [searchTerm]);
  // Helper to check if any editing is active
  const isEditingActive = () => {
    return (
      editingCustomer || editingOrder || editingProductState || showAddOrderForm
    );
  };
  const customerOrders = useMemo(() => {
    return orders.filter((o) => o.customerId === selectedCustomer.id);
  }, [orders, selectedCustomer.id]);

  const filteredOrders = useMemo(() => {
    if (!debouncedSearch.trim()) return customerOrders;

    const term = debouncedSearch.toLowerCase();

    return customerOrders.filter((order) => {
      const orderMatch =
        order.orderNo?.toLowerCase().includes(term) ||
        order.orderStatus?.toLowerCase().includes(term);

      const productMatch = order.products?.some((p) =>
        [p.category, p.roomName, p.fabricName, p.fabricType, p.curtainRod]
          .filter(Boolean)
          .join(" ")
          .toLowerCase()
          .includes(term),
      );

      return orderMatch || productMatch;
    });
  }, [debouncedSearch, customerOrders]);
  const CustomerSnapshot = ({ filteredOrders }) => {
    if (!selectedCustomer) {
      return (
        <div className="border border-gray-200 rounded-2xl p-6 bg-gray-50 text-center">
          <p className="text-gray-500">
            No customer selected. Add a customer first.
          </p>
        </div>
      );
    }

    const hasPartial = customerOrders.some(
      (o) => o.paymentStatus === "Partial",
    );

    return (
      <div>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 mb-4">
          {/* Left side */}
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-sm px-3 py-2 bg-gray-900 hover:bg-black text-white rounded-lg cursor-pointer"
            >
              <FiArrowLeft /> Back
            </button>

            {/* <h2 className="text-lg font-semibold">Orders - {customer?.name}</h2> */}
          </div>

          {/* 🔍 Search Input */}
          <div className="relative w-full lg:w-80">
            <input
              type="text"
              placeholder="Search orders, products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl  outline-none"
            />

            {/* Search Icon */}
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
              <FiSearch className="w-4 h-4" />
            </span>

            {/* Clear Button */}
            {searchTerm && (
              <button
                onClick={() => setSearchTerm("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black"
              >
                <FiX size={16} />
              </button>
            )}
          </div>
        </div>
        <div className="border border-gray-200 rounded-2xl p-5 bg-white shadow-sm">
          <div className="flex justify-between gap-3 flex-wrap items-start">
            <div>
              <h3 className="text-3xl font-bold mb-2">
                {selectedCustomer.name}
              </h3>
              <div className="text-gray-500 text-sm">
                {selectedCustomer.mobile} • {selectedCustomer.city} •{" "}
                {selectedCustomer.address?.split(",")[0]}
              </div>

              <div className="flex gap-2 flex-wrap mt-3">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-green-100 text-green-700 border border-green-200">
                  {customerOrders.length > 1 ? "Repeat Customer" : "Regular"}
                </span>

                {hasPartial && (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 border border-orange-200">
                    Partial Payment
                  </span>
                )}

                <span className="px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-600 border border-gray-200">
                  {customerOrders.length} Order(s)
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                className="px-4 py-2 rounded-xl cursor-pointer bg-white border border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition"
                onClick={() => {
                  closeAllPanels();
                  setEditingCustomer(selectedCustomer);
                }}
                // onClick={() => {
                //   setEditingCustomer(selectedCustomer);
                //   setShowAddOrderForm(false);
                //   setEditingOrder(null);
                //   setEditingProductState(null);
                // }}
              >
                Edit Customer
              </button>
              <button
                className="px-4 py-2 rounded-xl cursor-pointer bg-white border border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition"
                onClick={() => {
                  closeAllPanels();
                  setShowAddOrderForm(true);
                }}
                // onClick={() => {
                //   setShowAddOrderForm(true);
                //   setEditingCustomer(null);
                //   setEditingOrder(null);
                //   setEditingProductState(null);
                // }}
              >
                Create New Order
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-3 mt-4 h-auto max-h-[1020px] overflow-y-auto orders-scroll">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="border border-gray-200 rounded-2xl p-4 bg-gray-50"
            >
              <div className="flex justify-between gap-3 flex-wrap items-center">
                <div>
                  <div className="font-extrabold text-xl">{order.orderNo}</div>
                </div>
                <div className="flex gap-2 items-center bg-white">
                  <span
                    className={`px-3 py-1 rounded-full text-xs lg:text-[16px]  font-bold border bg-white
    ${order.orderStatus === "Cancelled" ? "text-red-500  bg-green-700  border-red-300 " : ""}
    ${order.orderStatus === "Pending" ? "text-yellow-500 bg-green-700    0border-yellow-300" : "bg-white"}
    ${order.orderStatus === "Completed" ? "text-green-500  rder-green-300" : ""}
    ${order.orderStatus === "Processing" ? "text-blue-500 bg-red-700 border-blue-300" : ""}
  `}
                  >
                    {order.orderStatus}
                  </span>
                  <button
                    className="px-3 py-1 cursor-pointer rounded-lg bg-white border border-gray-300 text-sm hover:bg-gray-100"
                    onClick={() => {
                      closeAllPanels(); // ✅ reset everything first
                      setEditingOrder(order);
                    }}
                    // onClick={() => {
                    //   setEditingOrder(order);
                    //   setEditingProductState(null);
                    // }}
                  >
                    <i className="fas fa-edit text-green-600 hover:text-green-800 cursor-pointer"></i>
                  </button>
                  <button
                    className="px-3 py-1 cursor-pointer rounded-lg bg-white border border-red-300 text-red-600 text-sm hover:bg-red-50"
                    onClick={() => deleteOrder(order.id)}
                  >
                    <i className="fas fa-trash-alt text-red-600 hover:text-red-800 cursor-pointer"></i>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="bg-white rounded-xl p-3 border border-gray-200">
                  <small className="text-gray-500 block">Total</small>
                  <strong className="text-lg">
                    ₹{parseInt(order.total).toLocaleString()}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-gray-200">
                  <small className="text-gray-500 block">Advance</small>
                  <strong className="text-lg">
                    ₹{parseInt(order.advancePayment || 0).toLocaleString()}
                  </strong>
                </div>
                <div className="bg-white rounded-xl p-3 border border-gray-200">
                  <small className="text-gray-500 block">Delivery</small>
                  <strong className="text-lg">
                    {formatDate(order.deliveryDate)}
                  </strong>
                </div>
              </div>

              {/* Products list - now without inline editing */}
              {order.products?.map((product) => (
                <div
                  key={product.id}
                  className="mt-3 border border-gray-200 bg-white rounded-xl p-3"
                >
                  <div className="flex justify-between gap-2 flex-wrap items-center">
                    <p className="text-gray-500">
                      {product.category} • {product.roomName || ""}
                    </p>
                    {/* <span className="px-2 py-1 rounded-full text-xs bg-gray-100 border border-gray-200">
                      {product.curtainType}
                    </span> */}
                    <div className="flex gap-4">
                      <button
                        className="text-md text-green-500  cursor-pointer hover:text-green-700"
                        onClick={() => startProductEdit(order.id, product)}
                      >
                        <i className="fas fa-edit text-green-600 hover:text-green-800 cursor-pointer"></i>
                      </button>
                      <button
                        className="text-md text-red-500 cursor-pointer hover:text-red-700"
                        onClick={() => deleteProduct(order.id, product.id)}
                      >
                        <i className="fas fa-trash-alt text-red-600 hover:text-red-800 cursor-pointer"></i>
                      </button>
                    </div>
                  </div>
                  <div className="text-gray-500 text-sm mt-1">
                    Fabric: {product.fabricName || "N/A"} • {product.fabricType}{" "}
                    • Width: {product.width} • Height: {product.height}
                    {product.curtainRod && ` • Rod: ${product.curtainRod}`}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  };

  // format date
  const formatDate = (date) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  return (
    <div className="bg-[#eff1f6] h-screen   lg:h-[650px]">
      <div className="flex flex-col lg:flex-row w-full h-auto   p-4 gap-6">
        {/* Left Section - Order Details */}
        <div
          className={`transition-all duration-500 ease-in-out 
  ${isEditingActive() ? "lg:w-[40%]" : "lg:w-full"} 
  w-full rounded-2xl border bg-white p-5 shadow-sm 
  lg:sticky lg:top-4   overflow-y-auto`}
        >
          <div
            className={`transition-opacity duration-300 ${
              isEditingActive() ? "opacity-100" : "opacity-100"
            }`}
          >
            <CustomerSnapshot filteredOrders={filteredOrders} />
          </div>
        </div>

        {/* Right Section - Editing Forms (Slide in animation) */}
        <div
          className={`transition-all duration-500 ease-in-out transform 
  ${
    isEditingActive()
      ? "lg:w-[60%] lg:translate-x-0 opacity-100"
      : "lg:w-0 lg:translate-x-10 opacity-0 hidden lg:block"
  } 
  w-full overflow-hidden`}
        >
          <div className="h-full bg-white rounded-2xl shadow-sm border border-gray-100 animate-slideInRight lg:h-[calc(100vh-2rem)] lg:overflow-y-auto">
            <div className="min-h-full   animate-slideInRight">
              {isEditingActive() && (
                <button
                  onClick={closeAllPanels}
                  className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 transition cursor-pointer"
                >
                  <FiX size={18} />
                </button>
              )}

              {editingCustomer ? (
                <div className=" rounded-2xl p-5">
                  <h3 className="text-2xl font-bold mb-4">Edit Customer</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <input
                      placeholder="Customer Name"
                      value={editingCustomer.name}
                      onChange={(e) =>
                        setEditingCustomer({
                          ...editingCustomer,
                          name: e.target.value,
                        })
                      }
                      className="p-3 border border-gray-300 rounded-xl"
                    />
                    <input
                      placeholder="Mobile"
                      value={editingCustomer.mobile}
                      onChange={(e) =>
                        setEditingCustomer({
                          ...editingCustomer,
                          mobile: e.target.value,
                        })
                      }
                      className="p-3 border border-gray-300 rounded-xl"
                    />
                    <input
                      placeholder="Alternate Mobile"
                      value={editingCustomer.alternateMobile || ""}
                      onChange={(e) =>
                        setEditingCustomer({
                          ...editingCustomer,
                          alternateMobile: e.target.value,
                        })
                      }
                      className="p-3 border border-gray-300 rounded-xl"
                    />
                    <input
                      placeholder="City"
                      value={editingCustomer.city || ""}
                      onChange={(e) =>
                        setEditingCustomer({
                          ...editingCustomer,
                          city: e.target.value,
                        })
                      }
                      className="p-3 border border-gray-300 rounded-xl"
                    />
                    <textarea
                      placeholder="Address"
                      rows="2"
                      value={editingCustomer.address || ""}
                      onChange={(e) =>
                        setEditingCustomer({
                          ...editingCustomer,
                          address: e.target.value,
                        })
                      }
                      className="md:col-span-2 p-3 border border-gray-300 rounded-xl"
                    ></textarea>
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      className="px-5 py-2 cursor-pointer bg-gray-300 text-gray-700 rounded-xl"
                      onClick={() => setEditingCustomer(null)}
                    >
                      Cancel
                    </button>
                    <button
                      className="px-5 py-2 bg-black cursor-pointer text-white rounded-xl"
                      onClick={handleUpdateCustomer}
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              ) : editingOrder ? (
                <AddOrder
                  order={{ ...editingOrder, products: [] }}
                  customers={customers}
                  selectedCustomerId={editingOrder.customerId}
                  onSave={handleUpdateOrder}
                  onCancel={() => setEditingOrder(null)}
                  title="Edit Order"
                />
              ) : editingProductState ? (
                <div className="bg-white rounded-2xl p-5">
                  <h3 className="text-2xl font-bold mb-4">Edit Product</h3>
                  <ProductForm
                    product={editingProductState}
                    index={0}
                    onUpdate={handleUpdateProductInline}
                    hideRemove={true}
                  />
                  <div className="flex gap-2 mt-6 mb-12 justify-end">
                    <button
                      onClick={cancelProductEdit}
                      className="px-5 py-2 bg-gray-300 cursor-pointer text-gray-700 rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={saveProductEdit}
                      className="px-5 py-2 bg-gray-800  cursor-pointer text-white rounded-xl"
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              ) : showAddOrderForm ? (
                <AddOrder
                  selectedCustomerId={selectedCustomer.id}
                  customers={customers}
                  onSave={handleOrderCreated}
                  onCancel={() => setShowAddOrderForm(false)}
                  title="Create New Order"
                />
              ) : (
                <></>
              )}
            </div>
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={showDeleteModal}
        title="Delete Order"
        message="Are you sure you want to delete this order? This action cannot be undone."
        onConfirm={confirmDeleteOrder}
        onCancel={() => {
          setShowDeleteModal(false);
          setOrderToDelete(null);
        }}
      />
      <ConfirmModal
        isOpen={showProductDeleteModal}
        title="Delete Product"
        message="Are you sure you want to delete this product? This action cannot be undone."
        onConfirm={confirmDeleteProduct}
        onCancel={() => {
          setShowProductDeleteModal(false);
          setProductToDelete(null);
          setProductOrderId(null);
        }}
      />

      <style>{`
        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        .animate-slideInRight {
          animation: slideInRight 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default OrderDetailsPage;

// import React, { useState } from "react";
// import { FiArrowLeft } from "react-icons/fi";
// import AddOrder from "./AddOrder";
// import ProductForm from "./ProductForm";
// import ConfirmModal from "./common/ConfirmModal";
// import { toast } from "react-toastify";
// const OrderDetailsPage = ({
//   customer,
//   orders,
//   onBack,
//   onDeleteOrder,
//   onDeleteProduct,
//   onAddNewOrder,
//   customers,
//   onUpdateCustomer,
//   onUpdateOrder,
//   onUpdateProduct,
// }) => {
//   const [showAddOrderForm, setShowAddOrderForm] = useState(false);
//   const [selectedCustomer, setSelectedCustomer] = useState(customer);
//   const [editingCustomer, setEditingCustomer] = useState(null);
//   const [editingOrder, setEditingOrder] = useState(null);
//   const [editingProductState, setEditingProductState] = useState(null); // Track product being edited
//   const [editingProductOrderId, setEditingProductOrderId] = useState(null); // Track which order contains the product
//   const [showDeleteModal, setShowDeleteModal] = useState(false);
//   const [orderToDelete, setOrderToDelete] = useState(null);
//   const [productToDelete, setProductToDelete] = useState(null);
//   const [productOrderId, setProductOrderId] = useState(null);
//   const [showProductDeleteModal, setShowProductDeleteModal] = useState(false);
//   const handleOrderCreated = (newOrder) => {
//     setShowAddOrderForm(false);

//     const completeOrder = {
//       ...newOrder,
//       id: "o" + Date.now(),
//       orderNo: newOrder.orderNo || `ORD-${Date.now()}`,
//       createdAt: new Date().toISOString(),
//       customerId: selectedCustomer.id,
//     };

//     if (onAddNewOrder) {
//       onAddNewOrder(completeOrder);
//     }
//   };

//   const deleteOrder = (orderId) => {
//     setOrderToDelete(orderId);
//     setShowDeleteModal(true);
//   };
//   const confirmDeleteOrder = () => {
//     if (onDeleteOrder && orderToDelete) {
//       onDeleteOrder(orderToDelete);
//     }
//     setShowDeleteModal(false);
//     setOrderToDelete(null);
//     setEditingOrder(null);
//   };
//   const deleteProduct = (orderId, productId) => {
//     setProductOrderId(orderId);
//     setProductToDelete(productId);
//     setShowProductDeleteModal(true);
//   };
//   const confirmDeleteProduct = () => {
//     if (onDeleteProduct && productOrderId && productToDelete) {
//       onDeleteProduct(productOrderId, productToDelete);
//     }

//     // Reset states
//     setShowProductDeleteModal(false);
//     setProductToDelete(null);
//     setProductOrderId(null);

//     // If editing same product → reset
//     if (editingProductState?.id === productToDelete) {
//       setEditingProductState(null);
//       setEditingProductOrderId(null);
//     }
//   };
//   const handleUpdateCustomer = () => {
//     if (onUpdateCustomer && editingCustomer) {
//       onUpdateCustomer(editingCustomer);
//       setSelectedCustomer(editingCustomer);
//     }
//     toast.success("Customer details updated successfully!");
//     setEditingCustomer(null);
//     setShowAddOrderForm(false);
//   };

//   const handleUpdateOrder = (updatedOrder) => {
//     if (onUpdateOrder) {
//       const originalOrder = orders.find((o) => o.id === updatedOrder.id);

//       const finalOrder = {
//         ...updatedOrder,
//         products: [
//           ...(originalOrder?.products || []), // old products
//           ...(updatedOrder.products || []), // new products
//         ],
//       };

//       onUpdateOrder(finalOrder);
//     }

//     setEditingOrder(null);
//   };
//   const startProductEdit = (orderId, product) => {
//     setEditingProductState(product);
//     setEditingProductOrderId(orderId);
//     // Clear other editing states
//     setEditingOrder(null);
//     setEditingCustomer(null);
//     setShowAddOrderForm(false);
//   };

//   const handleUpdateProductInline = (field, value) => {
//     setEditingProductState((prev) => ({
//       ...prev,
//       [field]: value,
//     }));
//   };

//   const saveProductEdit = () => {
//     if (onUpdateProduct && editingProductOrderId && editingProductState) {
//       onUpdateProduct(editingProductOrderId, editingProductState);
//       setEditingProductState(null);
//       setEditingProductOrderId(null);
//     }
//     toast.success("Product details updated successfully!");
//   };

//   const cancelProductEdit = () => {
//     setEditingProductState(null);
//     setEditingProductOrderId(null);
//   };

//   const CustomerSnapshot = () => {
//     if (!selectedCustomer) {
//       return (
//         <div className="border border-gray-200 rounded-2xl p-6 bg-gray-50 text-center">
//           <p className="text-gray-500">
//             No customer selected. Add a customer first.
//           </p>
//         </div>
//       );
//     }

//     const customerOrders = orders.filter(
//       (o) => o.customerId === selectedCustomer.id,
//     );
//     const hasPartial = customerOrders.some(
//       (o) => o.paymentStatus === "Partial",
//     );

//     return (
//       <div>
//         <div className="flex items-center justify-between mb-4">
//           <button
//             onClick={onBack}
//             className="flex items-center gap-2 text-sm px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg cursor-pointer"
//           >
//             <FiArrowLeft /> Back
//           </button>

//           <h2 className="text-lg font-semibold">Orders - {customer?.name}</h2>
//         </div>
//         <div className="border border-gray-200 rounded-2xl p-5 bg-white shadow-sm">
//           <div className="flex justify-between gap-3 flex-wrap items-start">
//             <div>
//               <h3 className="text-3xl font-bold mb-2">
//                 {selectedCustomer.name}
//               </h3>
//               <div className="text-gray-500 text-sm">
//                 {selectedCustomer.mobile} • {selectedCustomer.city} •{" "}
//                 {selectedCustomer.address?.split(",")[0]}
//               </div>

//               <div className="flex gap-2 flex-wrap mt-3">
//                 <span className="px-3 py-1 rounded-full text-xs font-bold bg-green-100 text-green-700 border border-green-200">
//                   {customerOrders.length > 1 ? "Repeat Customer" : "Regular"}
//                 </span>

//                 {hasPartial && (
//                   <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 border border-orange-200">
//                     Partial Payment
//                   </span>
//                 )}

//                 <span className="px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-600 border border-gray-200">
//                   {customerOrders.length} Order(s)
//                 </span>
//               </div>
//             </div>

//             <div className="flex gap-2">
//               <button
//                 className="px-4 py-2 rounded-xl cursor-pointer bg-white border border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition"
//                 onClick={() => {
//                   setEditingCustomer(selectedCustomer);
//                   setShowAddOrderForm(false);
//                   setEditingOrder(null);
//                   setEditingProductState(null);
//                 }}
//               >
//                 Edit Customer
//               </button>
//               <button
//                 className="px-4 py-2 rounded-xl cursor-pointer bg-white border border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition"
//                 onClick={() => {
//                   setShowAddOrderForm(true);
//                   setEditingCustomer(null);
//                   setEditingOrder(null);
//                   setEditingProductState(null);
//                 }}
//               >
//                 Create New Order
//               </button>
//             </div>
//           </div>
//         </div>

//         <div className="space-y-3 mt-4 h-auto max-h-[1020px] overflow-y-auto orders-scroll">
//           {customerOrders.map((order) => (
//             <div
//               key={order.id}
//               className="border border-gray-200 rounded-2xl p-4 bg-gray-50"
//             >
//               <div className="flex justify-between gap-3 flex-wrap items-center">
//                 <div>
//                   <div className="font-extrabold text-xl">{order.orderNo}</div>
//                   {/* <div className="text-gray-500 text-sm">
//                     {order.products
//                       ?.map((p) => p.roomName)
//                       .filter(Boolean)
//                       .join(", ") || "Order Items"}
//                   </div> */}
//                 </div>
//                 <div className="flex gap-2 items-center">
//                   <span className="px-3 py-1 rounded-full text-xs font-bold bg-white border border-gray-300">
//                     {order.orderStatus}
//                   </span>
//                   <button
//                     className="px-3 py-1 cursor-pointer rounded-lg bg-white border border-gray-300 text-sm hover:bg-gray-100"
//                     onClick={() => {
//                       setEditingOrder(order);
//                       setEditingProductState(null);
//                     }}
//                   >
//                     <i className="fas fa-edit text-green-600 hover:text-green-800 cursor-pointer"></i>
//                   </button>
//                   <button
//                     className="px-3 py-1 cursor-pointer rounded-lg bg-white border border-red-300 text-red-600 text-sm hover:bg-red-50"
//                     onClick={() => deleteOrder(order.id)}
//                   >
//                     <i className="fas fa-trash-alt text-red -600 hover:text-red-800 cursor-pointer"></i>
//                   </button>
//                 </div>
//               </div>

//               <div className="grid grid-cols-3 gap-3 mt-4">
//                 <div className="bg-white rounded-xl p-3 border border-gray-200">
//                   <small className="text-gray-500 block">Total</small>
//                   <strong className="text-lg">
//                     ₹{parseInt(order.total).toLocaleString()}
//                   </strong>
//                 </div>
//                 <div className="bg-white rounded-xl p-3 border border-gray-200">
//                   <small className="text-gray-500 block">Advance</small>
//                   <strong className="text-lg">
//                     ₹{parseInt(order.advancePayment || 0).toLocaleString()}
//                   </strong>
//                 </div>
//                 <div className="bg-white rounded-xl p-3 border border-gray-200">
//                   <small className="text-gray-500 block">Delivery</small>
//                   <strong className="text-lg">
//                     {formatDate(order.deliveryDate)}
//                   </strong>
//                 </div>
//               </div>

//               {/* Products list - now without inline editing */}
//               {order.products?.map((product) => (
//                 <div
//                   key={product.id}
//                   className="mt-3 border border-gray-200 bg-white rounded-xl p-3"
//                 >
//                   <div className="flex justify-between gap-2 flex-wrap items-center">
//                     <p className="text-gray-500">
//                       {product.category} • {product.roomName || ""}
//                     </p>
//                     <div className="flex gap-2">
//                       <span className="px-2 py-1 rounded-full text-xs bg-gray-100 border border-gray-200">
//                         {product.curtainType}
//                       </span>
//                       <button
//                         className="text-xs text-green-500 cursor-pointer hover:text-green-700"
//                         onClick={() => startProductEdit(order.id, product)}
//                       >
//                         <i className="fas fa-edit -alt text-red -600 hover:text-red-800 cursor-pointer"></i>
//                       </button>
//                       <button
//                         className="text-xs text-red-500 cursor-pointer hover:text-red-700"
//                         onClick={() => deleteProduct(order.id, product.id)}
//                       >
//                         <i className="fas fa-trash-alt text-red -600 hover:text-red-800 cursor-pointer"></i>
//                       </button>
//                     </div>
//                   </div>
//                   <div className="text-gray-500 text-sm mt-1">
//                     Fabric: {product.fabricName || "N/A"} • {product.fabricType}{" "}
//                     • Width: {product.width} • Height: {product.height}
//                     {product.curtainRod && ` • Rod: ${product.curtainRod}`}
//                   </div>
//                 </div>
//               ))}
//             </div>
//           ))}
//         </div>
//       </div>
//     );
//   };

//   //  format date
//   const formatDate = (date) => {
//     if (!date) return "";

//     return new Date(date).toLocaleDateString("en-GB", {
//       day: "2-digit",
//       month: "short",
//       year: "numeric",
//     });
//   };
//   return (
//     <div className="bg-[#eff1f6]">
//       <div className="flex flex-col lg:flex-row w-full p-4 gap-6">
//         <div className="rounded-2xl border bg-white p-5 shadow-sm w-1/2">
//           <CustomerSnapshot />
//         </div>

//         <div className="min-h-screen w-1/2 bg-white">
//           {editingCustomer ? (
//             <div className="bg-white rounded-2xl border border-gray-300 p-5">
//               <h3 className="text-2xl font-bold mb-4">Edit Customer</h3>
//               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
//                 <input
//                   placeholder="Customer Name"
//                   value={editingCustomer.name}
//                   onChange={(e) =>
//                     setEditingCustomer({
//                       ...editingCustomer,
//                       name: e.target.value,
//                     })
//                   }
//                   className="p-3 border border-gray-300 rounded-xl"
//                 />
//                 <input
//                   placeholder="Mobile"
//                   value={editingCustomer.mobile}
//                   onChange={(e) =>
//                     setEditingCustomer({
//                       ...editingCustomer,
//                       mobile: e.target.value,
//                     })
//                   }
//                   className="p-3 border border-gray-300 rounded-xl"
//                 />
//                 <input
//                   placeholder="Alternate Mobile"
//                   value={editingCustomer.alternateMobile || ""}
//                   onChange={(e) =>
//                     setEditingCustomer({
//                       ...editingCustomer,
//                       alternateMobile: e.target.value,
//                     })
//                   }
//                   className="p-3 border border-gray-300 rounded-xl"
//                 />
//                 <input
//                   placeholder="City"
//                   value={editingCustomer.city || ""}
//                   onChange={(e) =>
//                     setEditingCustomer({
//                       ...editingCustomer,
//                       city: e.target.value,
//                     })
//                   }
//                   className="p-3 border border-gray-300 rounded-xl"
//                 />
//                 <textarea
//                   placeholder="Address"
//                   rows="2"
//                   value={editingCustomer.address || ""}
//                   onChange={(e) =>
//                     setEditingCustomer({
//                       ...editingCustomer,
//                       address: e.target.value,
//                     })
//                   }
//                   className="md:col-span-2 p-3 border border-gray-300 rounded-xl"
//                 ></textarea>
//               </div>

//               <div className="flex justify-end gap-2">
//                 <button
//                   className="px-5 py-2 cursor-pointer bg-gray-300 text-gray-700 rounded-xl"
//                   onClick={() => setEditingCustomer(null)}
//                 >
//                   Cancel
//                 </button>
//                 <button
//                   className="px-5 py-2 bg-black cursor-pointer text-white rounded-xl"
//                   onClick={handleUpdateCustomer}
//                 >
//                   Save Changes
//                 </button>
//               </div>
//             </div>
//           ) : editingOrder ? (
//             <AddOrder
//               order={{ ...editingOrder, products: [] }}
//               customers={customers}
//               selectedCustomerId={editingOrder.customerId}
//               onSave={handleUpdateOrder}
//               onCancel={() => setEditingOrder(null)}
//               title="Edit Order"
//             />
//           ) : editingProductState ? (
//             // ✅ Product Edit Form on Right Side
//             <div className="bg-white rounded-2xl border border-gray-300 p-5">
//               <h3 className="text-2xl font-bold mb-4">Edit Product</h3>
//               <ProductForm
//                 product={editingProductState}
//                 index={0}
//                 onUpdate={handleUpdateProductInline}
//                 hideRemove={true}
//               />
//               <div className="flex gap-2 mt-6 justify-end">
//                 <button
//                   onClick={cancelProductEdit}
//                   className="px-5 py-2 bg-gray-300 cursor-pointer text-gray-700 rounded-xl"
//                 >
//                   Cancel
//                 </button>
//                 <button
//                   onClick={saveProductEdit}
//                   className="px-5 py-2 bg-green-500 cursor-pointer text-white rounded-xl"
//                 >
//                   Save Changes
//                 </button>
//               </div>
//             </div>
//           ) : showAddOrderForm ? (
//             <AddOrder
//               selectedCustomerId={selectedCustomer.id}
//               customers={customers}
//               onSave={handleOrderCreated}
//               onCancel={() => setShowAddOrderForm(false)}
//               title="Create New Order"
//             />
//           ) : (
//             <></>
//           )}
//         </div>
//       </div>
//       <ConfirmModal
//         isOpen={showDeleteModal}
//         title="Delete Order"
//         message="Are you sure you want to delete this order? This action cannot be undone."
//         onConfirm={confirmDeleteOrder}
//         onCancel={() => {
//           setShowDeleteModal(false);
//           setOrderToDelete(null);
//         }}
//       />
//       <ConfirmModal
//         isOpen={showProductDeleteModal}
//         title="Delete Product"
//         message="Are you sure you want to delete this product? This action cannot be undone."
//         onConfirm={confirmDeleteProduct}
//         onCancel={() => {
//           setShowProductDeleteModal(false);
//           setProductToDelete(null);
//           setProductOrderId(null);
//         }}
//       />
//     </div>
//   );
// };

// export default OrderDetailsPage;
