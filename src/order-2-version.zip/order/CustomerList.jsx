import React, { useState } from "react";
import { FiTrash2, FiPlus } from "react-icons/fi";
import ConfirmModal from "./common/ConfirmModal";
import { FiSearch, FiMapPin, FiX } from "react-icons/fi";
import AddCustomer from "./AddCustomer";
const ITEMS_PER_PAGE = 6;

const CustomerList = ({
  customers,
  orders,
  onViewOrders,
  onAddCustomer,
  onDeleteCustomer,
}) => {
  const [showCityDropdown, setShowCityDropdown] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [cityFilter, setCityFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState(null);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const filtegrayCustomers = customers
    .filter((customer) => {
      const term = searchTerm.toLowerCase();

      const matchesSearch =
        customer.name?.toLowerCase().includes(term) ||
        customer.mobile?.toLowerCase().includes(term) ||
        customer.city?.toLowerCase().includes(term) ||
        customer.address?.toLowerCase().includes(term);

      const matchesCity = cityFilter ? customer.city === cityFilter : true;

      return matchesSearch && matchesCity;
    })
    .sort((a, b) => {
      // newest first (descending)
      return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
    });
  //  automatic go to first page if not customer in 2nd page

  const uniqueCities = [...new Set(customers.map((c) => c.city))];

  const totalPages = Math.ceil(filtegrayCustomers.length / ITEMS_PER_PAGE);

  const paginatedCustomers = filtegrayCustomers.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE,
  );
  const confirmDeleteCustomer = () => {
    if (onDeleteCustomer && customerToDelete) {
      onDeleteCustomer(customerToDelete.id);
    }

    // adjust page manually
    const newTotal = filtegrayCustomers.length - 1;
    const newTotalPages = Math.ceil(newTotal / ITEMS_PER_PAGE);

    if (currentPage > newTotalPages) {
      setCurrentPage(newTotalPages || 1);
    }

    setShowDeleteModal(false);
    setCustomerToDelete(null);
  };

  return (
    <div className="bg-white border border-gray-200 shadow-sm overflow-hidden ">
      {showCreateForm ? (
        <AddCustomer
          onSave={(data, goToNext) => {
            onAddCustomer(data, goToNext); // ← Pass goToNext to parent
            if (!goToNext) {
              setShowCreateForm(false); // Only close form if NOT going to next page
            }
          }}
          onCancel={() => setShowCreateForm(false)}
        />
      ) : (
        // <AddCustomer
        //   onSave={(data) => {
        //     onAddCustomer(data);
        //     setShowCreateForm(false); // Go back to list view
        //   }}
        //   onCancel={() => setShowCreateForm(false)} // Go back to list view
        // />
        <>
          {/* Filters */}
          <div className="p-4    shadow-sm">
            <div className="flex justify-between items-center mb-3">
              {/* search and filter */}
              <div className="flex flex-col md:flex-row md:items-center gap-3">
                {/* 🔍 Search Input */}
                <div className="relative w-full md:w-1/2 max-w-[220px]">
                  <FiSearch
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    size={16}
                  />
                  <input
                    type="text"
                    placeholder="Search customers..."
                    className="w-full pl-10 pr-4 py-2.5 text-sm border border-gray-300 rounded-xl bg-gray-50 
        focus:bg-white focus:outline-none focus:ring-2 focus:ring-gray-200 focus:border-gray-400
        transition-all duration-200 shadow-sm"
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setCurrentPage(1);
                    }}
                  />
                </div>

                {/* 📍 City Filter */}
                <div className="relative w-[150px]">
                  {/* Trigger */}
                  <div
                    onClick={() => setShowCityDropdown((prev) => !prev)}
                    className="pl-10 pr-8 py-2.5 cursor-pointer text-sm border border-gray-300 rounded-xl bg-gray-50 
    flex items-center justify-between hover:bg-white transition shadow-sm"
                  >
                    <FiMapPin
                      className="absolute left-3 text-gray-400"
                      size={16}
                    />
                    <span
                      className={`${cityFilter ? "text-gray-800" : "text-gray-400"}`}
                    >
                      {cityFilter || "All Cities"}
                    </span>
                    <span className="text-gray-200 text-xs">▼</span>
                  </div>

                  {/* Dropdown */}
                  {showCityDropdown && (
                    <div className="absolute z-50 mt-2 w-full bg-white border border-gray-200 rounded-xl shadow-lg max-h-60 overflow-y-auto">
                      <div
                        onClick={() => {
                          setCityFilter("");
                          setShowCityDropdown(false);
                          setCurrentPage(1);
                        }}
                        className="px-4 py-2 text-sm hover:bg-gray-200 cursor-pointer"
                      >
                        All Cities
                      </div>

                      {uniqueCities.map((city, i) => (
                        <div
                          key={i}
                          onClick={() => {
                            setCityFilter(city);
                            setShowCityDropdown(false);
                            setCurrentPage(1);
                          }}
                          className="px-4 py-2 text-sm  hover:bg-gray-200 cursor-pointer"
                        >
                          {city}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* ❌ Clear Button */}
                {(searchTerm || cityFilter) && (
                  <button
                    className="flex cursor-pointer items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium 
      bg-gray-100 hover:bg-gray-50 text-gray-700 hover:text-gray-600 
      rounded-xl transition-all duration-200 border border-gray-200 hover:border-gray-200 shadow-sm"
                    onClick={() => {
                      setSearchTerm("");
                      setCityFilter("");
                      setCurrentPage(1);
                    }}
                  >
                    <FiX size={16} />
                    Clear
                  </button>
                )}
              </div>
              {/* create customer */}
              <div>
                <button
                  onClick={() => setShowCreateForm(true)}
                  className="group flex items-center gap-2 px-5 cursor-pointer py-2.5 
               bg-gradient-to-r from-gray-900 to-gray-700 
               text-white text-sm font-medium 
               rounded-xl shadow-md 
               hover:shadow-lg hover:from-black hover:to-gray-800
               active:scale-95 transition-all duration-200"
                >
                  <FiPlus className="text-lg transition-transform duration-200 group-hover:rotate-90" />
                  Create Customer
                </button>
              </div>
            </div>
          </div>
          {/* Table */}
          <div className="overflow-x-auto lg:h-[430px]">
            <table className="w-full table-fixed text-lg">
              <thead className="bg-black text-white sticky top-0 z-[40]">
                <tr>
                  <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                    Name
                  </th>
                  <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                    Mobile
                  </th>
                  <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                    City
                  </th>
                  <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                    Orders
                  </th>
                  <th className="px-4 py-3 font-bold text-lg sticky right-0 z-[120] bg-black shadow-[-4px_0_6px_-2px_rgba(0,0,0,0.1)]">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody className="text-[16px]">
                {paginatedCustomers.map((customer) => {
                  const orderCount = orders.filter(
                    (o) => o.customerId === customer.id,
                  ).length;

                  return (
                    <tr
                      key={customer.id}
                      className="hover:bg-gray-50 h-[60px] "
                    >
                      <td className="text-center">{customer.name}</td>

                      <td className="text-center ">{customer.mobile}</td>

                      <td className="text-center ">{customer.city}</td>

                      <td className="text-center">
                        <span className="px-2.5 py-1 text-xs bg-gray-100 text-gray-700 rounded-full">
                          {orderCount}
                        </span>
                      </td>

                      <td className="flex items-center justify-center pt-4">
                        <div className="flex text-center gap-2">
                          <button
                            className="px-3 py-1.5 text-sm bg-gray-900 text-white rounded-md cursor-pointer hover:bg-black transition"
                            onClick={() => onViewOrders(customer)}
                          >
                            View Orders
                          </button>
                          <button
                            className="p-2 rounded-md text-xl cursor-pointer hover:bg-gray-50  transition"
                            onClick={() => {
                              setCustomerToDelete(customer);
                              setShowDeleteModal(true);
                            }}
                          >
                            <FiTrash2 size={16} />
                          </button>
                          {/* <button
                        className="p-2 rounded-md cursor-pointer hover:bg-gray-50 text-gray-500 transition"
                        onClick={() => onDeleteCustomer(customer.id)}
                      >
                        <FiTrash2 size={16} />
                      </button> */}
                        </div>
                      </td>
                    </tr>
                  );
                })}

                {paginatedCustomers.length === 0 && (
                  <tr>
                    <td colSpan="5" className="p-8 text-center text-gray-400">
                      No matching customers found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-6 pt-4 pb-2 border-t border-gray-200">
              <span className="text-sm text-gray-700">
                Page {currentPage} of {totalPages}
              </span>

              <div className="flex gap-6 ">
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                  className="px-4 py-2 bg-black text-white rounded hover:bg-black-500 disabled:opacity-50  cursor-pointer disabled:cursor-not-allowed"
                >
                  <i className="fa-solid fa-arrow-left"></i> Previous
                </button>

                <button
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((p) => p + 1)}
                  className="px-4 py-2 bg-black text-white rounded hover:bg-black-500 disabled:opacity-50  cursor-pointer disabled:cursor-not-allowed"
                >
                  Next <i className="fa-solid fa-arrow-right"></i>
                </button>
              </div>
            </div>
          )}{" "}
        </>
      )}

      <ConfirmModal
        isOpen={showDeleteModal}
        title="Delete Customer"
        message={`Are you sure you want to delete ${
          customerToDelete?.name || "this customer"
        }? This action cannot be undone.`}
        onConfirm={confirmDeleteCustomer}
        onCancel={() => {
          setShowDeleteModal(false);
          setCustomerToDelete(null);
        }}
      />
    </div>
  );
};

export default CustomerList;

// import React, { useState } from "react";
// import { FiTrash2 } from "react-icons/fi";

// const CustomerList = ({
//   customers,
//   orders,
//   onViewOrders,
//   onDeleteCustomer,
// }) => {
//   const [searchTerm, setSearchTerm] = useState("");
//   const [cityFilter, setCityFilter] = useState("");

//   // 🔍 Filter logic
//   const filtegrayCustomers = customers.filter((customer) => {
//     const term = searchTerm.toLowerCase();

//     const matchesSearch =
//       customer.name?.toLowerCase().includes(term) ||
//       customer.mobile?.toLowerCase().includes(term) ||
//       customer.city?.toLowerCase().includes(term) ||
//       customer.address?.toLowerCase().includes(term);

//     const matchesCity = cityFilter ? customer.city === cityFilter : true;

//     return matchesSearch && matchesCity;
//   });

//   // 🎯 Unique cities for dropdown
//   const uniqueCities = [...new Set(customers.map((c) => c.city))];

//   return (
//     <div className="bg-white  border border-gray-300 overflow-hidden">
//       {/* Header */}
//       <div className="p-4 bg-gray-900 text-white">
//         <h3 className="text-xl font-bold">Customer List</h3>
//       </div>

//       {/* 🔎 Filters */}
//       <div className="p-4 flex flex-col md:flex-row gap-3 max-w-[800px] border-b">
//         <input
//           type="text"
//           placeholder="Search by name, mobile, city, address..."
//           className="border rounded-lg px-3 py-2 w-full md:w-1/2 max-w-[300px]"
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />

//         <select
//           className="border rounded-lg px-3 py-2 w-full md:w-1/4"
//           value={cityFilter}
//           onChange={(e) => setCityFilter(e.target.value)}
//         >
//           <option value="">All Cities</option>
//           {uniqueCities.map((city, i) => (
//             <option key={i} value={city}>
//               {city}
//             </option>
//           ))}
//         </select>

//         {/* Clear Filters */}
//         <button
//           className="px-4 py-2 bg-gray-200 rounded-lg"
//           onClick={() => {
//             setSearchTerm("");
//             setCityFilter("");
//           }}
//         >
//           Clear
//         </button>
//       </div>

//       {/* Table */}
//       <div className="overflow-x-auto">
//         <table className="w-full">
//           <thead className="bg-gray-100">
//             <tr>
//               <th className="p-3 text-left">Name</th>
//               <th className="p-3 text-left">Mobile</th>
//               <th className="p-3 text-left">City</th>
//               <th className="p-3 text-left">Orders</th>
//               <th className="p-3 text-left">Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {filtegrayCustomers.map((customer) => {
//               const orderCount = orders.filter(
//                 (o) => o.customerId === customer.id,
//               ).length;

//               return (
//                 <tr key={customer.id} className="border-t border-gray-200">
//                   <td className="p-3 font-medium">{customer.name}</td>
//                   <td className="p-3">{customer.mobile}</td>
//                   <td className="p-3">{customer.city}</td>
//                   <td className="p-3">{orderCount}</td>
//                   <td className="p-3">
//                     <div className="flex gap-2">
//                       <button
//                         className="p-2 rounded flex items-center gap-1 bg-black text-white cursor-pointer hover:bg-gray-900 transition"
//                         onClick={() => onViewOrders(customer)}
//                       >
//                         View Orders
//                       </button>
//                       <button
//                         className="p-2 rounded  cursor-pointer  transition"
//                         onClick={() => onDeleteCustomer(customer.id)}
//                       >
//                         <FiTrash2 />
//                       </button>
//                     </div>
//                   </td>
//                 </tr>
//               );
//             })}

//             {filtegrayCustomers.length === 0 && (
//               <tr>
//                 <td colSpan="5" className="p-8 text-center text-gray-500">
//                   No matching customers found.
//                 </td>
//               </tr>
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// };

// export default CustomerList;
