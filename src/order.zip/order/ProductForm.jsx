// ProductForm.jsx
import React, { useEffect, useRef } from "react";
import { useForm, Controller } from "react-hook-form";
import productsData from "../products";
import FIELD_CONFIG from "../constants/inputFieldConfig";
import { ORDER_FIELDS } from "../constants/orderInputFields";
import FormField from "./common/FormField";

const ProductForm = ({ product, onUpdate, onRemove, hideRemove = false }) => {
  // Get all possible field names from all categories
  const getAllFieldNames = () => {
    const allFields = new Set();
    Object.values(ORDER_FIELDS).forEach((fields) => {
      fields.forEach((field) => allFields.add(field));
    });
    return Array.from(allFields);
  };

  // Create default values for all possible fields
  const createDefaultValues = () => {
    const defaults = {
      category: "",
      productcode: "",
      brand: "",
      productId: "",
      quantity: 1,
      deliveryDate: "",
      orderStatus: "Pending",
      specialNotes: "",
    };

    // Add all dynamic fields with empty values
    getAllFieldNames().forEach((field) => {
      if (!defaults[field]) {
        defaults[field] = "";
      }
    });

    return defaults;
  };

  const { setValue, watch, control, reset } = useForm({
    defaultValues: product || createDefaultValues(),
  });

  const categoryKeyMap = {
    curtains: "curtains",
    "sofa-&seating": "sofaSeating",
    mattress: "mattress",
    "bed-linen": "bedLinen",
    "bath-linen": "bathLinen",
    flooring: "flooring",
    wallpapers: "wallpapers",
    rugs: "rugs",
    blinds: "blinds",
    "glass-films": "glassFilms",
    pillows: "pillows",
  };

  const selectedCategory = watch("category");
  const selectedBrand = watch("brand");
  const fieldsToRender = ORDER_FIELDS[categoryKeyMap[selectedCategory]] || [];
  const categoryData = productsData.find(
    (cat) => cat.slug === selectedCategory,
  );

  const brands = categoryData?.brands || [];
  const brandData = brands.find((b) => b.name === selectedBrand);
  const products = brandData?.products || [];

  const isUpdatingFromProp = useRef(false);
  const previousProductRef = useRef(product);
  const previousCategoryRef = useRef(selectedCategory);

  // Watch all form values and send to parent
  useEffect(() => {
    const subscription = watch((value) => {
      if (!isUpdatingFromProp.current && onUpdate) {
        onUpdate(value);
      }
    });
    return () => subscription.unsubscribe();
  }, [watch, onUpdate]);

  // Update form when product prop changes (for editing)
  useEffect(() => {
    if (
      product &&
      JSON.stringify(previousProductRef.current) !== JSON.stringify(product)
    ) {
      isUpdatingFromProp.current = true;
      previousProductRef.current = product;

      // Reset the form with new product values
      reset(product);

      setTimeout(() => {
        isUpdatingFromProp.current = false;
      }, 100);
    }
  }, [product, reset]);

  // Handle category change - clear all category-specific fields
  useEffect(() => {
    if (
      !isUpdatingFromProp.current &&
      previousCategoryRef.current !== selectedCategory
    ) {
      previousCategoryRef.current = selectedCategory;

      // Get all fields that should be cleared
      const allFields = getAllFieldNames();

      // Clear all dynamic fields when category changes
      allFields.forEach((field) => {
        setValue(field, "");
      });

      // Reset brand and product
      setValue("brand", "");
      setValue("productId", "");
    }
  }, [selectedCategory, setValue]);

  // Clear product when brand changes
  useEffect(() => {
    if (!isUpdatingFromProp.current) {
      setValue("productId", "");
    }
  }, [selectedBrand, setValue]);

  return (
    <div
      key={selectedCategory + selectedBrand}
      className="border border-gray-200 rounded-xl p-4 mt-4"
    >
      <div className="flex justify-between items-center mb-3">
        <h5 className="font-bold text-lg">Product Details</h5>
        {!hideRemove && onRemove && (
          <button
            className="px-3 py-1 rounded-lg bg-white border border-red-300 text-red-600 text-sm hover:bg-red-50"
            onClick={onRemove}
            type="button"
          >
            Remove
          </button>
        )}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* category */}
        <FormField
          name="category"
          label="Category"
          type="select"
          control={control}
          options={productsData.map((cat) => ({
            value: cat.slug,
            label: cat.title,
          }))}
        />

        {/* product code */}
        <FormField
          name="productcode"
          label="Product Code"
          type="input"
          control={control}
        />

        {/* brand field */}
        {/* {brands.length > 0 && (
          <FormField
            name="brand"
            label="Brand"
            type="select"
            control={control}
            options={brands.map((b) => ({
              value: b.name,
              label: b.name,
            }))}
          />
        )} */}

        {/* product selection field */}
        {products.length > 0 && (
          <FormField
            name="productId"
            label="Product"
            type="select"
            control={control}
            options={products.map((p) => ({
              value: p.id,
              label: p.name,
            }))}
          />
        )}

        {/* dynamic fields from ORDER_FIELDS */}
        {fieldsToRender.map((fieldName) => {
          const config = FIELD_CONFIG[fieldName] || {};
          return (
            <FormField
              key={fieldName}
              name={fieldName}
              label={config.label || fieldName}
              type={config.type || "input"}
              control={control}
              options={config.options || []}
            />
          );
        })}
      </div>
    </div>
  );
};

export default ProductForm;
// import React, { useEffect, useRef } from "react";
// import { useForm, Controller } from "react-hook-form";
// import productsData from "../products";
// import FIELD_CONFIG from "../constants/inputFieldConfig";
// import { ORDER_FIELDS } from "../constants/orderInputFields";
// import { SelectStyles, InputStyles, TextareaStyles } from "../constants/Config";
// import Select from "react-select";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";

// import FormField from "./common/FormField";

// const ProductForm = ({
//   product,

//   onUpdate,
//   onRemove,
//   hideRemove = false,
// }) => {
//   const { setValue, watch, control } = useForm({
//     defaultValues: product || {
//       category: "",
//       roomName: "",
//       curtainType: "",
//       fabricName: "",
//       fabricType: "Light Filtering",
//       material: "",
//       width: "",
//       height: "",
//       quantity: 1,
//       curtainRod: "",
//       rodLength: "",
//       lining: "No",
//       stitchingStyle: "",
//       accessories: "",
//       installation: "Required",
//       specialNotes: "",
//     },
//   });

//   // map slug → ORDER_FIELDS key
//   const categoryKeyMap = {
//     curtains: "curtains",
//     "sofa-&seating": "sofaSeating",
//     mattress: "mattress",
//     "bed-linen": "bedLinen",
//     "bath-linen": "bathLinen",
//     flooring: "flooring",
//     wallpaper: "wallpaper",
//     rugs: "rugs",
//     blinds: "blinds",
//     "glass-films": "glassFilms",
//     pillows: "pillows",
//   };

//   const selectedCategory = watch("category");
//   const selectedBrand = watch("brand");
//   const fieldsToRender = ORDER_FIELDS[categoryKeyMap[selectedCategory]] || [];
//   const categoryData = productsData.find(
//     (cat) => cat.slug === selectedCategory,
//   );

//   const brands = categoryData?.brands || [];

//   const brandData = brands.find((b) => b.name === selectedBrand);

//   const products = brandData?.products || [];

//   // Use ref to track if we're updating from prop to avoid loops
//   const isUpdatingFromProp = useRef(false);
//   const previousProductRef = useRef(product);
//   useEffect(() => {
//     setValue("brand", "");
//     setValue("productId", "");
//   }, [selectedCategory]);

//   useEffect(() => {
//     setValue("productId", "");
//   }, [selectedBrand]);
//   // Watch all form values

//   // Update parent when form values change (but not when updating from prop)
//   useEffect(() => {
//     if (!isUpdatingFromProp.current && onUpdate) {
//       const subscription = watch((value, { name }) => {
//         if (name) {
//           onUpdate(name, value[name]);
//         }
//       });
//       return () => subscription.unsubscribe();
//     }
//   }, [watch, onUpdate]);

//   // Update form when product prop changes (but avoid infinite loop)
//   useEffect(() => {
//     // Check if product actually changed
//     if (
//       product &&
//       JSON.stringify(previousProductRef.current) !== JSON.stringify(product)
//     ) {
//       isUpdatingFromProp.current = true;
//       previousProductRef.current = product;

//       Object.keys(product).forEach((key) => {
//         if (product[key] !== undefined) {
//           setValue(key, product[key]);
//         }
//       });

//       // Reset the flag after a delay
//       setTimeout(() => {
//         isUpdatingFromProp.current = false;
//       }, 100);
//     }
//   }, [product, setValue]);
//   useEffect(() => {
//     const fields = ORDER_FIELDS[categoryKeyMap[selectedCategory]] || [];

//     fields.forEach((field) => {
//       setValue(field, "");
//     });
//   }, [selectedCategory]);
//   return (
//     <div
//       key={selectedCategory + selectedBrand}
//       className="border border-gray-200 rounded-xl p-4 mt-4 "
//     >
//       <div className="flex justify-between items-center mb-3">
//         <h5 className="font-bold text-lg">Product Details</h5>
//         {!hideRemove && onRemove && (
//           <button
//             className="px-3 py-1 rounded-lg bg-white border border-red-300 text-red-600 text-sm hover:bg-red-50"
//             onClick={onRemove}
//             type="button"
//           >
//             Remove
//           </button>
//         )}
//       </div>
//       <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
//         {/* category */}
//         <FormField
//           name="category"
//           label="Category"
//           type="select"
//           control={control}
//           options={productsData.map((cat) => ({
//             value: cat.slug,
//             label: cat.title,
//           }))}
//         />

//         {/* brand */}
//         {/* <FormField
//           name="brand"
//           label="Brand"
//           type="select"
//           control={control}
//           options={brands.map((b) => ({
//             value: b.name,
//             label: b.name,
//           }))}
//         /> */}

//         {/* product */}
//         {/* <FormField
//           name="productId"
//           label="Product"
//           type="select"
//           control={control}
//           options={products.map((p) => ({
//             value: p.id,
//             label: p.name,
//           }))}
//         /> */}
//         {/*product code */}
//         <FormField
//           name="productcode"
//           label="Product Code"
//           type="input"
//           control={control}
//         />
//         {/* 🔥 dynamic fields */}
//         {fieldsToRender.map((fieldName) => {
//           const config = FIELD_CONFIG[fieldName] || {};

//           return (
//             <FormField
//               key={fieldName}
//               name={fieldName}
//               label={config.label || fieldName}
//               type={config.type || "input"}
//               control={control}
//               options={config.options || []}
//             />
//           );
//         })}
//       </div>
//     </div>
//   );
// };

// export default ProductForm;
