// utils/localStorage.js
export const getCustomers = () => {
  const stored = localStorage.getItem("showroom_customers");
  if (stored) return JSON.parse(stored);
  return [];
};

export const getOrders = () => {
  const stored = localStorage.getItem("showroom_orders");
  if (stored) return JSON.parse(stored);
  return [];
};

export const saveCustomers = (customers) =>
  localStorage.setItem("showroom_customers", JSON.stringify(customers));

export const saveOrders = (orders) =>
  localStorage.setItem("showroom_orders", JSON.stringify(orders));
