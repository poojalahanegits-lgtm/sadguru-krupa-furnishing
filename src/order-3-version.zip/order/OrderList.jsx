// components/orders/OrderList.jsx
import React from "react";
import { FiTrash2, FiSearch, FiX } from "react-icons/fi";
import { useState } from "react";
import { FiArrowLeft } from "react-icons/fi";
const ITEMS_PER_PAGE = 6;

const OrderList = ({ orders, customers, onViewDetails, onDeleteOrder }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("all");

  // 🔽 Sort + Filter
  // const filteredOrders = [...orders]
  //   .filter((order) => {
  //     const term = searchTerm.toLowerCase();

  //     return (
  //       order.orderNo?.toLowerCase().includes(term) ||
  //       order.customerName?.toLowerCase().includes(term) ||
  //       order.orderStatus?.toLowerCase().includes(term) ||
  //       order.orderDate?.toLowerCase().includes(term)
  //     );
  //   })
  //   .sort((a, b) => {
  //     return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
  //   });

  const filteredOrders = [...orders]
    .filter((order) => {
      const term = searchTerm.toLowerCase();

      const matchesSearch =
        order.orderNo?.toLowerCase().includes(term) ||
        order.customerName?.toLowerCase().includes(term) ||
        order.orderStatus?.toLowerCase().includes(term) ||
        order.orderDate?.toLowerCase().includes(term);

      const matchesStatus =
        statusFilter === "all" ||
        order.orderStatus?.toLowerCase() === statusFilter;

      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
    });
  // 📄 Pagination logic
  const totalPages = Math.ceil(filteredOrders.length / ITEMS_PER_PAGE);

  const paginatedOrders = filteredOrders.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE,
  );
  const sortedOrders = [...orders].sort((a, b) => {
    return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
  });
  return (
    <div className="bg-white border border-gray-300 overflow-hidden">
      {/* 🔍 Search Bar */}
      <div className="p-4 border-b flex flex-col md:flex-row gap-3 items-center">
        <div className="relative w-full md:w-1/3">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search orders..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-gray-200 outline-none"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>
        {searchTerm && (
          <button
            onClick={() => {
              setSearchTerm("");
              setCurrentPage(1);
            }}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-gray-100 rounded-lg hover:bg-gray-200"
          >
            <FiX size={14} /> Clear
          </button>
        )}

        <div>
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-gray-200 outline-none"
          >
            <option value="all">All Orders</option>
            <option value="open">Open</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <div className="overflow-x-auto lg:h-[436px]">
        <table className="w-full table-fixed text-lg">
          <thead className="bg-black text-white sticky top-0 z-[40]">
            <tr>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Order No
              </th>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Customer
              </th>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Date
              </th>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Delivery
              </th>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Status
              </th>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Total
              </th>
              <th className="px-4 border py-3  text-center font-semibold text-white  whitespace-nowrap  bg-black">
                Products
              </th>
              <th className="px-4 py-3 font-bold text-lg sticky right-0 z-[120] bg-black shadow-[-4px_0_6px_-2px_rgba(0,0,0,0.1)]">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {paginatedOrders.map((order) => (
              <tr key={order.id} className="border-t text-sm border-gray-200">
                <td className="text-center ">{order.orderNo}</td>
                <td className="text-center">{order.customerName}</td>
                <td className="text-center">{order.orderDate}</td>
                <td className="text-center">{order.deliveryDate}</td>
                <td className="text-center">
                  <span className="px-2 py-1 rounded-full text-xs bg-blue-100">
                    {order.orderStatus}
                  </span>
                </td>
                <td className="p-3 text-center">
                  ₹{parseInt(order.total).toLocaleString()}
                </td>
                <td className="p-3 text-center">
                  <div className="space-y-1">
                    {/* {order.products.slice(0, 2).map((p) => (
                      <div key={p.id} className="text-sm">
                        {p.category} - {p.roomName || "N/A"} (Qty: {p.quantity})
                      </div>
                    ))} */}
                    {order.products.length > 2 && (
                      <div className="text-xs text-gray-500">
                        {order.products.length}
                      </div>
                    )}
                  </div>
                </td>
                <td className="p-3">
                  <div className="flex gap-2  ] rounded-md px-2 py-1 cursor-pointer">
                    <button
                      className="py-2 px-4 bg-black text-white  rounded flex items-center gap-1 cursor-pointer"
                      onClick={() => {
                        const customer = customers.find(
                          (c) => c.id === order.customerId,
                        );
                        onViewDetails(order, customer);
                      }}
                    >
                      View Details
                    </button>
                    <button
                      className="p-2  rounded cursor-pointer"
                      onClick={() => onDeleteOrder(order.id)}
                    >
                      <FiTrash2 />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan="8" className="p-8 text-center text-gray-500">
                  No orders found. Add an order.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {/* 📄 Pagination (hide if only 1 page) */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-6 pt-4 pb-2 border-t border-gray-200">
          <span className="text-sm text-gray-700">
            Page {currentPage} of {totalPages}
          </span>

          <div className="flex gap-6">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
              className="px-4 py-2 bg-black text-white rounded hover:bg-black-500 disabled:opacity-50  cursor-pointer disabled:cursor-not-allowed"
            >
              <i className="fa-solid fa-arrow-left"></i> Previous
            </button>

            <button
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => p + 1)}
              className="px-4 py-2 bg-black text-white rounded hover:bg-black-500 disabled:opacity-50  cursor-pointer disabled:cursor-not-allowed"
            >
              Next <i className="fa-solid fa-arrow-right"></i>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderList;

// // components/orders/OrderList.jsx
// import React from "react";
// import { FiTrash2, FiSearch, FiX } from "react-icons/fi";
// import { useState } from "react";
// import { FiArrowLeft } from "react-icons/fi";
// const ITEMS_PER_PAGE = 6;

// const OrderList = ({ orders, customers, onViewDetails, onDeleteOrder }) => {
//   const [searchTerm, setSearchTerm] = useState("");
//   const [currentPage, setCurrentPage] = useState(1);

//   // 🔽 Sort + Filter
//   const filteredOrders = [...orders]
//     .filter((order) => {
//       const term = searchTerm.toLowerCase();

//       return (
//         order.orderNo?.toLowerCase().includes(term) ||
//         order.customerName?.toLowerCase().includes(term) ||
//         order.orderStatus?.toLowerCase().includes(term) ||
//         order.orderDate?.toLowerCase().includes(term)
//       );
//     })
//     .sort((a, b) => {
//       return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
//     });

//   // 📄 Pagination logic
//   const totalPages = Math.ceil(filteredOrders.length / ITEMS_PER_PAGE);

//   const paginatedOrders = filteredOrders.slice(
//     (currentPage - 1) * ITEMS_PER_PAGE,
//     currentPage * ITEMS_PER_PAGE,
//   );
//   const sortedOrders = [...orders].sort((a, b) => {
//     return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
//   });
//   return (
//     <div className="bg-white border border-gray-300 overflow-hidden">
//       {/* 🔍 Search Bar */}
//       <div className="p-4 border-b flex flex-col md:flex-row gap-3 items-center">
//         <div className="relative w-full md:w-1/3">
//           <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
//           <input
//             type="text"
//             placeholder="Search orders..."
//             className="w-full pl-10 pr-4 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-gray-200 outline-none"
//             value={searchTerm}
//             onChange={(e) => {
//               setSearchTerm(e.target.value);
//               setCurrentPage(1);
//             }}
//           />
//         </div>

//         <button
//           onClick={() => {
//             setSearchTerm("");
//             setCurrentPage(1);
//           }}
//           className="flex items-center gap-2 px-4 py-2 text-sm bg-gray-100 rounded-lg hover:bg-gray-200"
//         >
//           <FiX size={14} /> Clear
//         </button>
//       </div>

//       <div className="overflow-x-auto">
//         <table className="w-full">
//           <thead className="bg-black text-white">
//             <tr>
//               <th className="p-3 text-left">Order No</th>
//               <th className="p-3 text-left">Customer</th>
//               <th className="p-3 text-left">Date</th>
//               <th className="p-3 text-left">Delivery</th>
//               <th className="p-3 text-left">Status</th>
//               <th className="p-3 text-left">Total</th>
//               <th className="p-3 text-left">Products</th>
//               <th className="p-3 text-left">Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {sortedOrders.map((order) => (
//               <tr key={order.id} className="border-t border-gray-200">
//                 <td className="p-3 font-medium">{order.orderNo}</td>
//                 <td className="p-3">{order.customerName}</td>
//                 <td className="p-3">{order.orderDate}</td>
//                 <td className="p-3">{order.deliveryDate}</td>
//                 <td className="p-3">
//                   <span className="px-2 py-1 rounded-full text-xs bg-blue-100">
//                     {order.orderStatus}
//                   </span>
//                 </td>
//                 <td className="p-3">
//                   ₹{parseInt(order.total).toLocaleString()}
//                 </td>
//                 <td className="p-3">
//                   <div className="space-y-1">
//                     {order.products.slice(0, 2).map((p) => (
//                       <div key={p.id} className="text-sm">
//                         {p.category} - {p.roomName || "N/A"} (Qty: {p.quantity})
//                       </div>
//                     ))}
//                     {order.products.length > 2 && (
//                       <div className="text-xs text-gray-500">
//                         +{order.products.length - 2} more
//                       </div>
//                     )}
//                   </div>
//                 </td>
//                 <td className="p-3">
//                   <div className="flex gap-2  ] rounded-md px-2 py-1 cursor-pointer">
//                     <button
//                       className="py-2 px-4 bg-black text-white  rounded flex items-center gap-1"
//                       onClick={() => {
//                         const customer = customers.find(
//                           (c) => c.id === order.customerId,
//                         );
//                         onViewDetails(order, customer);
//                       }}
//                     >
//                       View Details
//                     </button>
//                     <button
//                       className="p-2  rounded"
//                       onClick={() => onDeleteOrder(order.id)}
//                     >
//                       <FiTrash2 />
//                     </button>
//                   </div>
//                 </td>
//               </tr>
//             ))}
//             {orders.length === 0 && (
//               <tr>
//                 <td colSpan="8" className="p-8 text-center text-gray-500">
//                   No orders found. Add an order.
//                 </td>
//               </tr>
//             )}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );
// };

// export default OrderList;
