import React, { useState, useEffect } from "react";
// UI Components (child components)
import Tabs from "./Tabs";
import CustomerList from "./CustomerList";
import AddCustomer from "./AddCustomer";
import OrderList from "./OrderList";
import ConfirmModal from "./common/ConfirmModal";
import OrderDetailsPage from "./OrdersDetailsPage";
// Local storage helpers (data persistence)
import {
  getCustomers,
  getOrders,
  saveCustomers,
  saveOrders,
} from "./localStorage";
// Initial static data (not currently used but useful for first load)

import AddOrder from "./AddOrder.jsx";

const ShowroomCRM = () => {
  // =========================
  // 🔹 STATE MANAGEMENT
  // =========================
  // Controls which tab is active (Customer List / Add Customer / Order List)
  const [activeTab, setActiveTab] = useState("customerList");

  // Main data states
  const [customers, setCustomers] = useState([]); // all customers
  const [orders, setOrders] = useState([]); // all orders

  // Selected entities for detail view
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  if (selectedOrder) {
    console.log(selectedOrder);
  }
  // Page control (list view vs details page)
  const [activePage, setActivePage] = useState("list");

  // Editing states (for modal)
  const [editingOrder, setEditingOrder] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null);

  // Delete confirmation modal states
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState(null);
  const [showAddCustomer, setShowAddCustomer] = useState(false);

  // =========================
  // 🔹 INITIAL DATA LOAD
  // =========================

  // Runs once when component mounts
  useEffect(() => {
    // Load data from localStorage
    setCustomers(getCustomers());
    setOrders(getOrders());
  }, []);

  // Parent component (where OrderDetailsPage is used)
  const handleUpdateProduct = (orderId, updatedProduct) => {
    setOrders((prevOrders) =>
      prevOrders.map((order) => {
        if (order.id === orderId) {
          return {
            ...order,
            products: order.products.map((product) =>
              product.id === updatedProduct.id ? updatedProduct : product,
            ),
          };
        }
        return order;
      }),
    );

    // Save to localStorage or API
    localStorage.setItem("orders", JSON.stringify(orders));
    alert("Product updated successfully!");
  };

  // Update customers in state + localStorage
  const updateCustomers = (newCustomers) => {
    setCustomers(newCustomers);
    saveCustomers(newCustomers);
  };

  // Update orders in state + localStorage
  const updateOrders = (newOrders) => {
    setOrders(newOrders);
    saveOrders(newOrders);
  };

  // =========================
  // 🔹 CUSTOMER CRUD
  // =========================

  // ➕ Add new customer
  const addCustomer = (customerData) => {
    const newId = "c" + Date.now();
    const newCustomer = {
      ...customerData,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    const newCustomers = [...customers, newCustomer];
    updateCustomers(newCustomers);
    return newCustomer;
  };
  // ✏️ Update existing customer
  const updateCustomer = (customerData) => {
    const newCustomers = customers.map((c) =>
      c.id === customerData.id ? customerData : c,
    );
    updateCustomers(newCustomers);
  };

  // ❌ Delete customer + their orders
  const deleteCustomer = (id) => {
    // Remove all orders belonging to this customer
    const filteredOrders = orders.filter((o) => o.customerId !== id);
    updateOrders(filteredOrders);

    // Remove customer
    const filteredCustomers = customers.filter((c) => c.id !== id);
    updateCustomers(filteredCustomers);
  };

  // =========================
  // 🔹 ORDER CRUD
  // =========================

  const updateOrder = (orderData) => {
    const newOrders = orders.map((o) =>
      o.id === orderData.id ? orderData : o,
    );
    updateOrders(newOrders);
    setEditingOrder(null);
    setEditingProduct(null);
  };

  // order delete
  const handleAskDeleteOrder = (orderId) => {
    setOrderToDelete(orderId);
    setConfirmOpen(true);
  };
  // order delte confirmation
  const handleConfirmDelete = () => {
    const newOrders = orders.filter((o) => o.id !== orderToDelete);
    updateOrders(newOrders);

    setConfirmOpen(false);
    setOrderToDelete(null);
  };
  // =========================
  // 🔹 PRODUCT MANAGEMENT INSIDE ORDER
  // =========================

  // ❌ Delete product from order
  const deleteProduct = (orderId, productId) => {
    const order = orders.find((o) => o.id === orderId);
    if (order && order.products.length === 1) {
      if (
        confirm(
          "Order has only one product. Deleting it will remove entire order. Continue?",
        )
      ) {
        handleAskDeleteOrder(orderId);
      }
    } else {
      const updatedOrders = orders.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            products: o.products.filter((p) => p.id !== productId),
          };
        }
        return o;
      });
      updateOrders(updatedOrders);
    }
  };

  // ✏️ Update product inside order
  const updateProductInOrder = (orderId, updatedProduct) => {
    setOrders((prevOrders) => {
      const updatedOrders = prevOrders.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            products: o.products.map((p) =>
              p.id === updatedProduct.id ? updatedProduct : p,
            ),
          };
        }
        return o;
      });

      // ✅ persist correctly
      saveOrders(updatedOrders);

      return updatedOrders;
    });
  };
  // const updateProductInOrder = (orderId, updatedProduct) => {
  //   const updatedOrders = orders.map((o) => {
  //     if (o.id === orderId) {
  //       return {
  //         ...o,
  //         products: o.products.map((p) =>
  //           p.id === updatedProduct.id ? updatedProduct : p,
  //         ),
  //       };
  //     }
  //     return o;
  //   });
  //   updateOrders(updatedOrders);
  // };
  // =========================
  // 🔹 TABS CONFIGURATION
  // =========================
  const tabs = [
    { id: "customerList", label: "Customer List", icon: "FiUsers" },
    // { id: "addCustomer", label: "Add Customer", icon: "FiPlus" },
    { id: "orderList", label: "Order List", icon: "FiShoppingCart" },
  ];
  // =========================
  // 🔹 ADD CUSTOMER FLOW CONTROL
  // =========================
  const handleAddCustomer = (customerData, goToNext = false) => {
    const newCustomer = addCustomer(customerData);

    if (goToNext) {
      setSelectedCustomer(newCustomer);
      setActivePage("details");
    } else {
      setActiveTab("customerList");
    }
  };
  // =========================
  // 🔹 MAIN RENDER LOGIC
  // =========================
  const renderContent = () => {
    // Order details page view
    if (activePage === "details" && selectedCustomer) {
      return (
        <OrderDetailsPage
          customer={selectedCustomer}
          orders={orders.filter((o) => o.customerId === selectedCustomer.id)}
          onBack={() => {
            setActivePage("list");
            setSelectedCustomer(null);
          }}
          onDeleteOrder={handleAskDeleteOrder}
          onDeleteProduct={deleteProduct}
          onAddNewOrder={(newOrder) => {
            const updatedOrders = [...orders, newOrder];
            updateOrders(updatedOrders);
          }}
          customers={customers}
          onUpdateCustomer={updateCustomer}
          onUpdateOrder={updateOrder}
          onUpdateProduct={updateProductInOrder}
          // onUpdateProduct={handleUpdateProduct}
        />
      );
    }

    // 👥 Customer List
    if (activeTab === "customerList") {
      return (
        <CustomerList
          customers={customers}
          orders={orders}
          onViewOrders={(customer) => {
            setSelectedCustomer(customer);
            setActivePage("details");
          }}
          onDeleteCustomer={deleteCustomer}
          onAddCustomer={handleAddCustomer}
          // onSave={handleAddCustomer}
        />
      );
    }
    // ➕ Add Customer
    // if (activeTab === "addCustomer") {
    //   return (
    //     <AddCustomer
    //       onSave={handleAddCustomer}
    //       onCancel={() => setActiveTab("customerList")}
    //     />
    //   );
    // }
    // 📦 Order List
    if (activeTab === "orderList") {
      return (
        <OrderList
          orders={orders}
          customers={customers}
          onViewDetails={(order, customer) => {
            setSelectedOrder(order);
            setSelectedCustomer(customer);
            setActivePage("details");
          }}
          onDeleteOrder={handleAskDeleteOrder}
        />
      );
    }

    return null;
  };
  // =========================
  // 🔹 MAIN JSX
  // =========================
  return (
    <div className="max-h-screen    ">
      {/* Tabs (hidden in details page) */}
      {activePage === "list" && (
        <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
      )}

      {/* Dynamic Content */}
      <div className="bg-white">{renderContent()}</div>

      {/* Edit Order Modal */}
      {editingOrder && !editingProduct && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-auto"
          onClick={() => {
            setEditingOrder(null);
            setEditingProduct(null);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-6xl w-full max-h-[90vh] overflow-auto"
          >
            <AddOrder
              order={editingOrder}
              customers={customers}
              selectedCustomerId={editingOrder.customerId}
              onSave={(data) => {
                updateOrder(data);
                setEditingOrder(null);
              }}
              onCancel={() => {
                setEditingOrder(null);
                setEditingProduct(null);
              }}
            />
          </div>
        </div>
      )}

      {/* confirm model for order delete */}
      <ConfirmModal
        isOpen={confirmOpen}
        title="Delete Order"
        message="Are you sure you want to delete this order? This action cannot be undone."
        onConfirm={handleConfirmDelete}
        onCancel={() => {
          setConfirmOpen(false);
          setOrderToDelete(null);
        }}
      />
    </div>
  );
};

export default ShowroomCRM;

// import React, { useState, useEffect } from "react";
// // UI Components (child components)
// import Tabs from "./Tabs";
// import CustomerList from "./CustomerList";
// import AddCustomer from "./AddCustomer";
// import OrderList from "./OrderList";
// import ConfirmModal from "./common/ConfirmModal";
// import OrderDetailsPage from "./OrdersDetailsPage";
// // Local storage helpers (data persistence)
// import {
//   getCustomers,
//   getOrders,
//   saveCustomers,
//   saveOrders,
// } from "./localStorage";
// // Initial static data (not currently used but useful for first load)
// import { INITIAL_CUSTOMERS, INITIAL_ORDERS } from "./initialData.js";
// import AddOrder from "./AddOrder.jsx";

// const ShowroomCRM = () => {
//   // =========================
//   // 🔹 STATE MANAGEMENT
//   // =========================
//   // Controls which tab is active (Customer List / Add Customer / Order List)
//   const [activeTab, setActiveTab] = useState("customerList");

//   // Main data states
//   const [customers, setCustomers] = useState([]); // all customers
//   const [orders, setOrders] = useState([]); // all orders

//   // Selected entities for detail view
//   const [selectedCustomer, setSelectedCustomer] = useState(null);
//   const [selectedOrder, setSelectedOrder] = useState(null);

//   // Page control (list view vs details page)
//   const [activePage, setActivePage] = useState("list");

//   // Editing states (for modal)
//   const [editingOrder, setEditingOrder] = useState(null);
//   const [editingProduct, setEditingProduct] = useState(null);

//   // Flow control (not currently used)
//   const [showAddOrderAfterCustomer, setShowAddOrderAfterCustomer] =
//     useState(false);

//   // Delete confirmation modal states
//   const [confirmOpen, setConfirmOpen] = useState(false);
//   const [orderToDelete, setOrderToDelete] = useState(null);

//   // =========================
//   // 🔹 INITIAL DATA LOAD
//   // =========================

//   // Runs once when component mounts
//   useEffect(() => {
//     // Load data from localStorage
//     setCustomers(getCustomers());
//     setOrders(getOrders());
//   }, []);

//   // Update customers in state + localStorage
//   const updateCustomers = (newCustomers) => {
//     setCustomers(newCustomers);
//     saveCustomers(newCustomers);
//   };

//   // Update orders in state + localStorage
//   const updateOrders = (newOrders) => {
//     setOrders(newOrders);
//     saveOrders(newOrders);
//   };

//   // =========================
//   // 🔹 CUSTOMER CRUD
//   // =========================

//   // ➕ Add new customer
//   const addCustomer = (customerData) => {
//     const newId = "c" + Date.now();
//     const newCustomer = {
//       ...customerData,
//       id: newId,
//       createdAt: new Date().toISOString(),
//     };
//     const newCustomers = [...customers, newCustomer];
//     updateCustomers(newCustomers);
//     return newCustomer;
//   };
//   // ✏️ Update existing customer
//   const updateCustomer = (customerData) => {
//     const newCustomers = customers.map((c) =>
//       c.id === customerData.id ? customerData : c,
//     );
//     updateCustomers(newCustomers);
//   };

//   // ❌ Delete customer + their orders
//   const deleteCustomer = (id) => {
//     // Remove all orders belonging to this customer
//     const filteredOrders = orders.filter((o) => o.customerId !== id);
//     updateOrders(filteredOrders);

//     // Remove customer
//     const filteredCustomers = customers.filter((c) => c.id !== id);
//     updateCustomers(filteredCustomers);
//   };

//   // =========================
//   // 🔹 ORDER CRUD
//   // =========================

//   // ➕ Add new order
//   const addOrder = (orderData) => {
//     const newOrder = {
//       ...orderData,
//       id: orderData.id || "o" + Date.now(),
//     };

//     const newOrders = [...orders, newOrder];
//     updateOrders(newOrders);
//     return newOrder;
//   };

//   const updateOrder = (orderData) => {
//     const newOrders = orders.map((o) =>
//       o.id === orderData.id ? orderData : o,
//     );
//     updateOrders(newOrders);
//     setEditingOrder(null);
//     setEditingProduct(null);
//   };

//   // order delete
//   const handleAskDeleteOrder = (orderId) => {
//     setOrderToDelete(orderId);
//     setConfirmOpen(true);
//   };
//   // order delte confirmation
//   const handleConfirmDelete = () => {
//     const newOrders = orders.filter((o) => o.id !== orderToDelete);
//     updateOrders(newOrders);

//     setConfirmOpen(false);
//     setOrderToDelete(null);
//   };
//   // =========================
//   // 🔹 PRODUCT MANAGEMENT INSIDE ORDER
//   // =========================

//   // ❌ Delete product from order
//   const deleteProduct = (orderId, productId) => {
//     const order = orders.find((o) => o.id === orderId);
//     if (order && order.products.length === 1) {
//       if (
//         confirm(
//           "Order has only one product. Deleting it will remove entire order. Continue?",
//         )
//       ) {
//         handleAskDeleteOrder(orderId);
//       }
//     } else {
//       const updatedOrders = orders.map((o) => {
//         if (o.id === orderId) {
//           return {
//             ...o,
//             products: o.products.filter((p) => p.id !== productId),
//           };
//         }
//         return o;
//       });
//       updateOrders(updatedOrders);
//     }
//   };
//   // ➕ Add product to order
//   const addProductToOrder = (orderId, product) => {
//     const updatedOrders = orders.map((o) => {
//       if (o.id === orderId) {
//         return { ...o, products: [...o.products, product] };
//       }
//       return o;
//     });
//     updateOrders(updatedOrders);
//   };
//   // ✏️ Update product inside order
//   const updateProductInOrder = (orderId, updatedProduct) => {
//     const updatedOrders = orders.map((o) => {
//       if (o.id === orderId) {
//         return {
//           ...o,
//           products: o.products.map((p) =>
//             p.id === updatedProduct.id ? updatedProduct : p,
//           ),
//         };
//       }
//       return o;
//     });
//     updateOrders(updatedOrders);
//   };
//   // =========================
//   // 🔹 TABS CONFIGURATION
//   // =========================
//   const tabs = [
//     { id: "customerList", label: "Customer List", icon: "FiUsers" },
//     { id: "addCustomer", label: "Add Customer", icon: "FiPlus" },
//     { id: "orderList", label: "Order List", icon: "FiShoppingCart" },
//   ];
//   // =========================
//   // 🔹 ADD CUSTOMER FLOW CONTROL
//   // =========================
//   const handleAddCustomer = (customerData, goToNext = false) => {
//     const newCustomer = addCustomer(customerData);

//     if (goToNext) {
//       setSelectedCustomer(newCustomer);
//       setActivePage("details");
//     } else {
//       setActiveTab("customerList");
//     }
//   };
//   // =========================
//   // 🔹 MAIN RENDER LOGIC
//   // =========================
//   const renderContent = () => {
//     // Order details page view
//     if (activePage === "details" && selectedCustomer) {
//       return (
//         <OrderDetailsPage
//           customer={selectedCustomer}
//           orders={orders.filter((o) => o.customerId === selectedCustomer.id)}
//           onBack={() => {
//             setActivePage("list");
//             setSelectedCustomer(null);
//             setSelectedOrder(null);
//           }}
//           onDeleteOrder={handleAskDeleteOrder}
//           onDeleteProduct={deleteProduct}
//           onAddNewOrder={(newOrder) => {
//             const updatedOrders = [...orders, newOrder];
//             updateOrders(updatedOrders);
//           }}
//           customers={customers}
//           onUpdateCustomer={updateCustomer}
//           onUpdateOrder={updateOrder}
//           onUpdateProduct={updateProductInOrder}
//         />
//       );
//     }

//     // 👥 Customer List
//     if (activeTab === "customerList") {
//       return (
//         <CustomerList
//           customers={customers}
//           orders={orders}
//           onViewOrders={(customer) => {
//             setSelectedCustomer(customer);
//             setActivePage("details");
//           }}
//           onDeleteCustomer={deleteCustomer}
//         />
//       );
//     }
//     // ➕ Add Customer
//     if (activeTab === "addCustomer") {
//       return (
//         <AddCustomer
//           onSave={handleAddCustomer}
//           onCancel={() => setActiveTab("customerList")}
//         />
//       );
//     }
//     // 📦 Order List
//     if (activeTab === "orderList") {
//       return (
//         <OrderList
//           orders={orders}
//           customers={customers}
//           onViewDetails={(order, customer) => {
//             setSelectedOrder(order);
//             setSelectedCustomer(customer);
//             setActivePage("details");
//           }}
//           onDeleteOrder={handleAskDeleteOrder}
//         />
//       );
//     }

//     return null;
//   };
//   // =========================
//   // 🔹 MAIN JSX
//   // =========================
//   return (
//     <div className="max-h-screen    ">
//       {/* Tabs (hidden in details page) */}
//       {activePage === "list" && !showAddOrderAfterCustomer && (
//         <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
//       )}

//       {/* Dynamic Content */}
//       <div className="bg-white">{renderContent()}</div>

//       {/* Edit Order Modal */}
//       {editingOrder && !editingProduct && (
//         <div
//           className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-auto"
//           onClick={() => {
//             setEditingOrder(null);
//             setEditingProduct(null);
//           }}
//         >
//           <div
//             onClick={(e) => e.stopPropagation()}
//             className="max-w-6xl w-full max-h-[90vh] overflow-auto"
//           >
//             <AddOrder
//               order={editingOrder}
//               customers={customers}
//               selectedCustomerId={editingOrder.customerId}
//               onSave={(data) => {
//                 updateOrder(data);
//                 setEditingOrder(null);
//               }}
//               onCancel={() => {
//                 setEditingOrder(null);
//                 setEditingProduct(null);
//               }}
//             />
//           </div>
//         </div>
//       )}

//       {/* confirm model for order delete */}
//       <ConfirmModal
//         isOpen={confirmOpen}
//         title="Delete Order"
//         message="Are you sure you want to delete this order? This action cannot be undone."
//         onConfirm={handleConfirmDelete}
//         onCancel={() => {
//           setConfirmOpen(false);
//           setOrderToDelete(null);
//         }}
//       />
//     </div>
//   );
// };

// export default ShowroomCRM;
