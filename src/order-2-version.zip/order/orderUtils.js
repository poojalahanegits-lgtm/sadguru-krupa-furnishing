// utils/orderUtils.js
import { ORDER_FIELDS } from "../constants/orderInputFields";

export const generateOrderNo = () => {
  const year = new Date().getFullYear();
  const random = Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, "0");
  return `SKF-${year}-${random}`;
};

export const calculateOrderTotal = (products) => {
  return products
    .reduce((sum, p) => sum + (parseInt(p.quantity) || 1) * 5000, 0)
    .toString();
};

// Category mapping
export const categoryKeyMap = {
  curtains: "curtains",
  "sofa-&seating": "sofaSeating",
  mattress: "mattress",
  "bed-linen": "bedLinen",
  "bath-linen": "bathLinen",
  flooring: "flooring",
  wallpapers: "wallpapers",
  rugs: "rugs",
  blinds: "blinds",
  "glass-films": "glassFilms",
  pillows: "pillows",
};

export const getCategoryFields = (categorySlug) => {
  const key = categoryKeyMap[categorySlug];
  return ORDER_FIELDS[key] || [];
};

// Get all possible field names from ORDER_FIELDS
export const getAllFieldNames = () => {
  const allFields = new Set();
  Object.values(ORDER_FIELDS).forEach((fields) => {
    fields.forEach((field) => allFields.add(field));
  });
  return Array.from(allFields);
};

export const emptyProduct = () => {
  const baseProduct = {
    id: null,
    category: "",
    productcode: "",
    brand: "",
    productId: "",
    quantity: 1,
    deliveryDate: "",
    orderStatus: "Pending",
    specialNotes: "",
  };

  // Add all dynamic fields with empty values
  getAllFieldNames().forEach((field) => {
    if (!baseProduct[field]) {
      baseProduct[field] = "";
    }
  });

  return baseProduct;
};

// Clean product data - remove fields not needed for current category
export const cleanProductData = (product) => {
  if (!product || !product.category) return product;

  const allowedFields = [
    ...getAllFieldNames(),
    "id",
    "category",
    "productcode",
    "brand",
    "productId",
    "quantity",
    "deliveryDate",
    "orderStatus",
    "specialNotes",
  ];

  const cleanedProduct = {};
  allowedFields.forEach((field) => {
    if (product[field] !== undefined) {
      cleanedProduct[field] = product[field];
    }
  });

  return cleanedProduct;
};

// // utils/orderUtils.js
// import { ORDER_FIELDS } from "../constants/orderInputFields";

// export const generateOrderNo = () => {
//   const year = new Date().getFullYear();
//   const random = Math.floor(Math.random() * 1000)
//     .toString()
//     .padStart(3, "0");
//   return `SKF-${year}-${random}`;
// };

// export const calculateOrderTotal = (products) => {
//   return products
//     .reduce((sum, p) => sum + (parseInt(p.quantity) || 1) * 5000, 0)
//     .toString();
// };

// // Add this helper function
// const categoryKeyMap = {
//   curtains: "curtains",
//   "sofa-&seating": "sofaSeating",
//   mattress: "mattress",
//   "bed-linen": "bedLinen",
//   "bath-linen": "bathLinen",
//   flooring: "flooring",
//   wallpapers: "wallpapers",
//   rugs: "rugs",
//   blinds: "blinds",
//   "glass-films": "glassFilms",
//   pillows: "pillows",
// };

// export const getCategoryFields = (categorySlug) => {
//   const key = categoryKeyMap[categorySlug];
//   return ORDER_FIELDS[key] || [];
// };

// // In orderUtils.js
// export const emptyProduct = () => {
//   // Get all possible field names from ORDER_FIELDS
//   const getAllFieldNames = () => {
//     const allFields = new Set();
//     Object.values(ORDER_FIELDS).forEach((fields) => {
//       fields.forEach((field) => allFields.add(field));
//     });
//     return Array.from(allFields);
//   };

//   const baseProduct = {
//     id: null,
//     category: "",
//     productcode: "",
//     brand: "",
//     productId: "",
//     quantity: 1,
//     deliveryDate: "",
//     orderStatus: "Pending",
//     specialNotes: "",
//   };

//   // Add all dynamic fields with empty values
//   getAllFieldNames().forEach((field) => {
//     if (!baseProduct[field]) {
//       baseProduct[field] = "";
//     }
//   });

//   return baseProduct;
// };
