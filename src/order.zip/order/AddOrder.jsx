import React, { useState, useEffect } from "react";
import { Controller, useForm } from "react-hook-form";
import { format } from "date-fns";
import { SelectStyles, InputStyles, TextareaStyles } from "../constants/Config";
import ProductForm from "./ProductForm";
import {
  generateOrderNo,
  calculateOrderTotal,
  emptyProduct,
  getCategoryFields, // Add this import
} from "./orderUtils";
import { FiX } from "react-icons/fi";
import { toast } from "react-toastify";
import FormField from "./common/FormField";

const formatDate = (date) => {
  if (!date) return "";

  const d = new Date(date);
  if (isNaN(d)) return "";

  return d.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const AddOrder = ({
  order,
  customers,
  selectedCustomerId,
  onSave,
  onCancel,
  isModal = false,
  title = "Add New Order",
}) => {
  const { register, handleSubmit, setValue, watch, getValues, control } =
    useForm({
      defaultValues: order || {
        orderNo: generateOrderNo(),
        orderDate: new Date().toISOString().slice(0, 10),
        deliveryDate: new Date(Date.now() + 7 * 86400000)
          .toISOString()
          .slice(0, 10),
        customerId: selectedCustomerId || customers[0]?.id || "",
        customerName: selectedCustomerId
          ? customers.find((c) => c.id === selectedCustomerId)?.name || ""
          : customers[0]?.name || "",
        paymentStatus: "Pending",
        orderStatus: "Pending",
        advancePayment: "0",
        discount: "0",
        staffAssigned: "",
        // siteVisitDate: "",
        // siteVisitTime: "",
        // siteAddress: "",
        // siteDetails: "",
        // attachments: [],
      },
    });

  const [products, setProducts] = useState(order?.products || []);
  const [currentProduct, setCurrentProduct] = useState(() => {
    // Initialize with empty product
    return emptyProduct();
  });

  const updateCurrentProduct = (updatedProduct) => {
    console.log("Updating current product:", updatedProduct);
    setCurrentProduct(updatedProduct);
  };

  const handleAddProduct = () => {
    console.log("Current product before add:", currentProduct);

    if (!currentProduct.category) {
      toast.warning("Please select a product category");
      return;
    }

    // Create a clean product object with only relevant fields
    const productToAdd = { ...currentProduct };

    // Remove undefined values
    Object.keys(productToAdd).forEach((key) => {
      if (productToAdd[key] === undefined) {
        productToAdd[key] = "";
      }
    });

    const newProduct = {
      ...productToAdd,
      id: Date.now(),
    };

    console.log("Adding product:", newProduct);
    setProducts([...products, newProduct]);

    // Reset current product to empty state
    const emptyProd = emptyProduct();
    setCurrentProduct(emptyProd);

    toast.success("Product added");
  };

  // For editing existing order, populate products correctly
  useEffect(() => {
    if (order?.products) {
      setProducts(order.products);
    }
  }, [order]);
  const removeProduct = (id) => {
    setProducts(products.filter((p) => p.id !== id));
    toast.info("Product removed");
  };

  const handleCustomerChange = (customerId) => {
    const customer = customers.find((c) => c.id === customerId);
    setValue("customerId", customerId);
    setValue("customerName", customer?.name || "");
  };

  const onSubmit = (data) => {
    console.log("Form data:", data);
    console.log("Products:", products);
    if (!data.customerId) {
      toast.dismiss();
      toast.error("Please select a customer");
      return;
    }

    if (!order && products.length === 0) {
      toast.dismiss();
      toast.error("Add at least 1 product");
      return;
    }

    const total = calculateOrderTotal(products);

    const finalOrder = {
      ...data,
      products,
      total,
    };

    console.log("🧾 FINAL ORDER:", finalOrder);
    onSave(finalOrder);
    // ✅ Success Toast
    toast.dismiss();
    toast.success(
      order ? "Order updated successfully 🎉" : "Order created successfully 🎉",
    );
  };

  const content = (
    <form
      onSubmit={handleSubmit(onSubmit)}
      onKeyDown={(e) => {
        if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") {
          e.preventDefault();
        }
      }}
    >
      <div className="mb-0 bg-white ">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Order Number */}
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-gray-600">
              Order Id
            </label>
            <input
              {...register("orderNo")}
              disabled
              className={`h-11 px-3 rounded-lg border ${
                order ? "bg-gray-100 cursor-not-allowed" : ""
              } border-gray-300 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none transition`}
              placeholder="Enter order number"
            />
          </div>

          {/* Order Date */}
          <div className="flex flex-col gap-1">
            <FormField
              name="orderDate"
              control={control}
              label="Order Date"
              type="date"
            />
          </div>

          {/* Delivery Date */}
          <div className="flex flex-col gap-1">
            <FormField
              name="deliveryDate"
              control={control}
              label="Delivery Date"
              type="date"
            />
          </div>
          {/* 💰 Total Amount */}
          <div className="flex flex-col gap-1">
            <FormField
              name="totalAmount"
              control={control}
              label="Total Amount"
              type="number"
              placeholder="Enter total amount"
              onChange={(e) => {
                const total = Number(e.target.value || 0);
                const received = Number(getValues("receivedAmount") || 0);
                setValue("dueAmount", total - received);
              }}
            />
          </div>

          {/* 💵 Received Amount */}
          <div className="flex flex-col gap-1">
            <FormField
              name="receivedAmount"
              control={control}
              label="Received Amount"
              type="number"
              placeholder="Enter received amount"
              onChange={(e) => {
                const received = Number(e.target.value || 0);
                const total = Number(getValues("totalAmount") || 0);
                setValue("dueAmount", total - received);
              }}
            />
          </div>

          {/* 🧾 Due Amount (Auto) */}
          <div className="flex flex-col gap-1">
            <FormField
              name="dueAmount"
              control={control}
              label="Due Amount"
              type="number"
              placeholder="Auto calculated"
              readOnly
            />
          </div>
          {/* Payment Status */}
          <div className="flex flex-col gap-1">
            <FormField
              name="staffAssigned"
              control={control}
              label="Manager"
              placeholder="Enter Manager name"
            />
          </div>

          {/* Order Status */}
          <div className="flex flex-col gap-1">
            <FormField
              name="orderStatus"
              control={control}
              label="Order Status"
              type="select"
              options={["Pending", "Processing", "Completed", "Cancelled"]}
            />
          </div>
          {/* Staff Assigned */}

          {/* Advance Payment */}
          {/* <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-gray-600">
              Advance Payment (₹)
            </label>
            <input
              type="number"
              {...register("advancePayment")}
              className="h-11 px-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none transition"
              placeholder="0.00"
            />
          </div> */}

          {/* Discount */}
          {/* <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-gray-600">
              Discount (₹)
            </label>
            <input
              type="number"
              {...register("discount")}
              className="h-11 px-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none transition"
              placeholder="0.00"
            />
          </div> */}
        </div>
      </div>
      {/* PRODUCTS */}
      <div className=" ">
        <div className=" rounded-xl">
          <ProductForm
            product={currentProduct}
            index={0}
            onUpdate={updateCurrentProduct}
            hideRemove
          />

          <button
            type="button"
            onClick={handleAddProduct}
            className="mt-3 px-4 py-2 cursor-pointer bg-gray-800 text-white rounded-xl"
          >
            + Add Product
          </button>
        </div>

        {products.length > 0 && (
          <div className="space-y-2">
            {products.map((p, idx) => (
              <div
                key={p.id}
                className="flex justify-between border p-3 rounded-xl"
              >
                <div>
                  #{idx + 1} - {p.category}
                  {/* Show additional fields if they exist */}
                  {p.width && ` | Width: ${p.width}`}
                  {p.height && ` | Height: ${p.height}`}
                  {p.quantity && ` | Qty: ${p.quantity}`}
                </div>
                <button type="button" onClick={() => removeProduct(p.id)}>
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SUMMARY */}
      {/* {products.length > 0 && (
        <div className="mt-4 p-4 bg-gray-50 rounded-xl">
          <strong className="text-xl">
            ₹{calculateOrderTotal(products).toLocaleString()}
          </strong>
        </div>
      )} */}

      {/* ACTIONS */}
      <div className="flex justify-end gap-3 my-6">
        <button
          type="button"
          onClick={onCancel}
          className="px-5 py-2 border rounded-xl"
        >
          Cancel
        </button>

        <button
          type="submit"
          className="px-5 py-2 cursor-pointer bg-black text-white rounded-xl"
        >
          {order ? "Update Order" : "Create Order"}
        </button>
      </div>
    </form>
  );

  return isModal ? (
    <div className="bg-white mt-20 rounded-2xl border p-6 max-w-4xl mx-auto">
      <div className="flex justify-between mb-4">
        <h3 className="text-2xl font-bold">{title}</h3>
        <button onClick={onCancel}>
          <FiX size={22} />
        </button>
      </div>
      {content}
    </div>
  ) : (
    <div className="bg-white rounded-2xl p-6">
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      {content}
    </div>
  );
};

export default AddOrder;

// import React, { useState, useEffect } from "react";
// import { Controller, useForm } from "react-hook-form";
// import { format } from "date-fns";
// import { SelectStyles, InputStyles, TextareaStyles } from "../constants/Config";
// import ProductForm from "./ProductForm";
// import {
//   generateOrderNo,
//   calculateOrderTotal,
//   emptyProduct,
// } from "./orderUtils";
// import { FiX } from "react-icons/fi";
// import { toast } from "react-toastify";
// import FormField from "./common/FormField";
// const formatDate = (date) => {
//   if (!date) return "";

//   const d = new Date(date);
//   if (isNaN(d)) return "";

//   return d.toLocaleDateString("en-GB", {
//     day: "2-digit",
//     month: "short",
//     year: "numeric",
//   });
// };
// const AddOrder = ({
//   order,
//   customers,
//   selectedCustomerId,
//   onSave,
//   onCancel,
//   isModal = false,
//   title = "Add New Order",
// }) => {
//   const { register, handleSubmit, setValue, watch, getValues, control } =
//     useForm({
//       defaultValues: order || {
//         orderNo: generateOrderNo(),
//         orderDate: new Date().toISOString().slice(0, 10),
//         deliveryDate: new Date(Date.now() + 7 * 86400000)
//           .toISOString()
//           .slice(0, 10),
//         customerId: selectedCustomerId || customers[0]?.id || "",
//         customerName: selectedCustomerId
//           ? customers.find((c) => c.id === selectedCustomerId)?.name || ""
//           : customers[0]?.name || "",
//         paymentStatus: "Pending",
//         orderStatus: "Pending",
//         advancePayment: "0",
//         discount: "0",
//         staffAssigned: "",
//         // siteVisitDate: "",
//         // siteVisitTime: "",
//         // siteAddress: "",
//         // siteDetails: "",
//         // attachments: [],
//       },
//     });

//   const [products, setProducts] = useState(order?.products || []);
//   const [currentProduct, setCurrentProduct] = useState(emptyProduct());
//   const selectedCustomer =
//     customers.find((c) => c.id === watch("customerId")) ||
//     customers.find((c) => c.id === selectedCustomerId);
//   const form = watch();

//   useEffect(() => {
//     if (selectedCustomerId && !order) {
//       const customer = customers.find((c) => c.id === selectedCustomerId);
//       setValue("customerId", selectedCustomerId);
//       setValue("customerName", customer?.name || "");
//     }
//   }, [selectedCustomerId, customers, order, setValue]);

//   const updateCurrentProduct = (field, value) => {
//     setCurrentProduct((prev) => ({
//       ...prev,
//       [field]: value,
//     }));
//   };

//   const handleAddProduct = () => {
//     if (!currentProduct.category) {
//       toast.warning("Please select a product category");
//       return;
//     }

//     const newProduct = {
//       ...currentProduct,
//       id: Date.now(),
//     };

//     setProducts([...products, newProduct]);
//     setCurrentProduct(emptyProduct());
//     toast.success("Product added");
//   };

//   const removeProduct = (id) => {
//     setProducts(products.filter((p) => p.id !== id));
//     toast.info("Product removed");
//   };

//   const handleCustomerChange = (customerId) => {
//     const customer = customers.find((c) => c.id === customerId);
//     setValue("customerId", customerId);
//     setValue("customerName", customer?.name || "");
//   };

//   const onSubmit = (data) => {
//     if (!data.customerId) {
//       toast.dismiss();
//       toast.error("Please select a customer");
//       return;
//     }

//     if (!order && products.length === 0) {
//       toast.dismiss();
//       toast.error("Add at least 1 product");
//       return;
//     }

//     const total = calculateOrderTotal(products);

//     const finalOrder = {
//       ...data,
//       products,
//       total,
//     };

//     //console.log("🧾 FINAL ORDER:", finalOrder);
//     onSave(finalOrder);
//     // ✅ Success Toast
//     toast.dismiss();
//     toast.success(
//       order ? "Order updated successfully 🎉" : "Order created successfully 🎉",
//     );
//   };

//   const content = (
//     <form
//       onSubmit={handleSubmit(onSubmit)}
//       onKeyDown={(e) => {
//         if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") {
//           e.preventDefault();
//         }
//       }}
//     >
//       <div className="mb-0 bg-white ">
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
//           {/* Order Number */}
//           <div className="flex flex-col gap-1">
//             <label className="text-sm font-medium text-gray-600">
//               Order Id
//             </label>
//             <input
//               {...register("orderNo")}
//               disabled
//               className={`h-11 px-3 rounded-lg border ${
//                 order ? "bg-gray-100 cursor-not-allowed" : ""
//               } border-gray-300 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none transition`}
//               placeholder="Enter order number"
//             />
//           </div>

//           {/* Order Date */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="orderDate"
//               control={control}
//               label="Order Date"
//               type="date"
//             />
//           </div>

//           {/* Delivery Date */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="deliveryDate"
//               control={control}
//               label="Delivery Date"
//               type="date"
//             />
//           </div>
//           {/* 💰 Total Amount */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="totalAmount"
//               control={control}
//               label="Total Amount"
//               type="number"
//               placeholder="Enter total amount"
//               onChange={(e) => {
//                 const total = Number(e.target.value || 0);
//                 const received = Number(getValues("receivedAmount") || 0);
//                 setValue("dueAmount", total - received);
//               }}
//             />
//           </div>

//           {/* 💵 Received Amount */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="receivedAmount"
//               control={control}
//               label="Received Amount"
//               type="number"
//               placeholder="Enter received amount"
//               onChange={(e) => {
//                 const received = Number(e.target.value || 0);
//                 const total = Number(getValues("totalAmount") || 0);
//                 setValue("dueAmount", total - received);
//               }}
//             />
//           </div>

//           {/* 🧾 Due Amount (Auto) */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="dueAmount"
//               control={control}
//               label="Due Amount"
//               type="number"
//               placeholder="Auto calculated"
//               readOnly
//             />
//           </div>
//           {/* Payment Status */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="staffAssigned"
//               control={control}
//               label="Staff Assigned"
//               placeholder="Enter staff name"
//             />
//           </div>

//           {/* Order Status */}
//           <div className="flex flex-col gap-1">
//             <FormField
//               name="orderStatus"
//               control={control}
//               label="Order Status"
//               type="select"
//               options={["Pending", "Processing", "Completed", "Cancelled"]}
//             />
//           </div>
//           {/* Staff Assigned */}

//           {/* Advance Payment */}
//           {/* <div className="flex flex-col gap-1">
//             <label className="text-sm font-medium text-gray-600">
//               Advance Payment (₹)
//             </label>
//             <input
//               type="number"
//               {...register("advancePayment")}
//               className="h-11 px-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none transition"
//               placeholder="0.00"
//             />
//           </div> */}

//           {/* Discount */}
//           {/* <div className="flex flex-col gap-1">
//             <label className="text-sm font-medium text-gray-600">
//               Discount (₹)
//             </label>
//             <input
//               type="number"
//               {...register("discount")}
//               className="h-11 px-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none transition"
//               placeholder="0.00"
//             />
//           </div> */}
//         </div>
//       </div>
//       {/* PRODUCTS */}
//       <div className=" ">
//         <div className=" rounded-xl">
//           <ProductForm
//             product={currentProduct}
//             index={0}
//             onUpdate={updateCurrentProduct}
//             hideRemove
//           />

//           <button
//             type="button"
//             onClick={handleAddProduct}
//             className="mt-3 px-4 py-2 cursor-pointer bg-gray-800 text-white rounded-xl"
//           >
//             + Add Product
//           </button>
//         </div>

//         {products.length > 0 && (
//           <div className="space-y-2">
//             {products.map((p, idx) => (
//               <div
//                 key={p.id}
//                 className="flex justify-between border p-3 rounded-xl"
//               >
//                 <div>
//                   #{idx + 1} - {p.category}
//                 </div>
//                 <button type="button" onClick={() => removeProduct(p.id)}>
//                   Remove
//                 </button>
//               </div>
//             ))}
//           </div>
//         )}
//       </div>

//       {/* SUMMARY */}
//       {/* {products.length > 0 && (
//         <div className="mt-4 p-4 bg-gray-50 rounded-xl">
//           <strong className="text-xl">
//             ₹{calculateOrderTotal(products).toLocaleString()}
//           </strong>
//         </div>
//       )} */}

//       {/* ACTIONS */}
//       <div className="flex justify-end gap-3 my-6">
//         <button
//           type="button"
//           onClick={onCancel}
//           className="px-5 py-2 border rounded-xl"
//         >
//           Cancel
//         </button>

//         <button
//           type="submit"
//           className="px-5 py-2 cursor-pointer bg-black text-white rounded-xl"
//         >
//           {order ? "Update Order" : "Create Order"}
//         </button>
//       </div>
//     </form>
//   );

//   return isModal ? (
//     <div className="bg-white mt-20 rounded-2xl border p-6 max-w-4xl mx-auto">
//       <div className="flex justify-between mb-4">
//         <h3 className="text-2xl font-bold">{title}</h3>
//         <button onClick={onCancel}>
//           <FiX size={22} />
//         </button>
//       </div>
//       {content}
//     </div>
//   ) : (
//     <div className="bg-white rounded-2xl p-6">
//       <h3 className="text-2xl font-bold mb-4">{title}</h3>
//       {content}
//     </div>
//   );
// };

// export default AddOrder;
